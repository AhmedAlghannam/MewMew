# mistral-code-24

Creating a platform that allows researchers to view their research logs in a digestible way to prevent security threats. A Code+ 2024 project.

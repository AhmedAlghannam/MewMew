from datetime import datetime
from sqlalchemy import Float, Index, UniqueConstraint, Column, String, Integer, DateTime, Date, ForeignKey, Index
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()

class SourceIP(Base):
    __tablename__ = 'src_ip'
    id = Column(Integer, primary_key=True)
    src_ip = Column(String, nullable=False, unique=True)
    count = Column(Integer, nullable=False)
    
    __table_args__ = (
        Index('idx_src_ip', 'src_ip'),  # Index on src_ip
    )

class DestinationIP(Base):
    __tablename__ = 'dest_ip'
    id = Column(Integer, primary_key=True)
    dest_ip = Column(String, nullable=False, unique=True)
    count = Column(Integer, nullable=False)
    ports = relationship("FlowSummary", back_populates="destination")
    
    __table_args__ = (
        Index('idx_dest_ip', 'dest_ip'),  # Index on dest_ip
    )

class FlowSummary(Base):
    __tablename__ = 'flow_summary'
    key = Column(Integer, primary_key=True)
    src_id = Column(Integer, ForeignKey('src_ip.id'), nullable=False)
    dest_id = Column(Integer, ForeignKey('dest_ip.id'), nullable=False)
    dest_port = Column(Integer, nullable=False)
    prot_num = Column(Integer, nullable=False)
    count = Column(Integer, nullable=False)
    destination = relationship("DestinationIP", back_populates="ports")
    time_stamps = relationship("TimeStamps", back_populates="flow")
    packets_summary = relationship("PacketsSummary", back_populates="flow")

    __table_args__ = (
        Index('idx_src_id', 'src_id'),
        Index('idx_dest_id', 'dest_id'),
        Index('idx_dest_port', 'dest_port'),
        Index('idx_prot_num', 'prot_num')
    )

class TimeStamps(Base):
    __tablename__ = 'time_stamps'
    id = Column(Integer, primary_key=True)
    flow_id = Column(Integer, ForeignKey('flow_summary.key'), nullable=False)
    date = Column(Date, nullable=False)
    hour = Column(Integer, nullable=False)
    duration = Column(Integer, nullable=False)
    count = Column(Integer, nullable=False)
    flow = relationship("FlowSummary", back_populates="time_stamps")

    __table_args__ = (
        Index('idx_flow_id', 'flow_id'),
        Index('idx_date', 'date'),
        Index('idx_hour', 'hour')
    )

class PacketsSummary(Base):
    __tablename__ = 'packets_summary'
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, nullable=False) 
    flow_id = Column(Integer, ForeignKey('flow_summary.key'), nullable=False)
    packets = Column(Integer, nullable=False)
    reverse_packets = Column(Integer, nullable=False)
    bytes = Column(Integer, nullable=False)
    reverse_bytes = Column(Integer, nullable=False)
    count = Column(Integer, nullable=False)
    flow = relationship("FlowSummary", back_populates="packets_summary")

    __table_args__ = (
        Index('idx_flow_id_packets', 'flow_id'),
        Index('idx_timestamp', 'timestamp')
    )

class ProcessedFiles(Base):
    __tablename__ = 'processed_files'
    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String, unique=True, nullable=False)
    processed_at = Column(DateTime, default=datetime.utcnow)
    
class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, autoincrement=True)
    net_id = Column(String, unique=True, nullable=False)
     
class IpUniqueDestPorts(Base):
    __tablename__ = 'ip_unique_dest'
    id = Column(Integer, primary_key=True, autoincrement=True)
    date = Column(Date, nullable=False)
    src_ip = Column(String, nullable=False)
    dest_port_string = Column(String, nullable=False)
    bytes = Column(Integer, nullable=False)
    reverse_bytes = Column(Integer, nullable=False)
    packets = Column(Integer, nullable=False)
    pcr = Column(Float, nullable=False)
    por = Column(Float, nullable=False)
    p_value = Column(Float, nullable=False)
    alert_classification = Column(String, nullable=False)
    
    # Define a composite unique constraint
    __table_args__ = (
        UniqueConstraint('date', 'src_ip', name='date_srcip_unique'),
    )
    
class DailySummary(Base):
    __tablename__ = 'daily_summary'
    id = Column(Integer, primary_key=True, autoincrement=True)
    date = Column(Date, nullable=False)
    hour = Column(Integer, nullable=False)
    src_ip = Column(String, nullable=False)
    dest_ip = Column(String, nullable=False)
    dest_port = Column(Integer, nullable=False)
    prot_num = Column(Integer, nullable=False)
    bytes = Column(Integer, nullable=False)
    
from marshmallow import fields
from rest_framework import serializers
from models import *
from marshmallow_sqlalchemy import SQLAlchemyAutoSchema

# turn data into JSON file format
class ReactSerializer(serializers.Serializer): 
    id = serializers.IntegerField()
    src_ip = serializers.CharField()
    count = serializers.IntegerField()

class SourceIPSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = SourceIP
        load_instance = True
        
class DestinationIPSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = DestinationIP
        load_instance = True

class FlowSummarySchema(SQLAlchemyAutoSchema):
    
    src_id = fields.Int()
    dest_id = fields.Int()
    class Meta:
        model = FlowSummary
        load_instance = True

    # nested field, so when we serialize FlowSummary, we serialize TimeStamp
    source_ip = fields.Nested(SourceIPSchema)
    destination_ip = fields.Nested(DestinationIPSchema)

class TimeStampsSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = TimeStamps
        load_instance = True
    
    duration = fields.Str()   
    flowsummary = fields.Nested(FlowSummarySchema)

class PacketsSummarySchema(SQLAlchemyAutoSchema):
    flowsummary = fields.Nested(FlowSummarySchema)

    class Meta:
        model = PacketsSummary
        load_instance = True
        
        
class IpUniqueDestPortsSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = IpUniqueDestPorts
        load_instance = True

    id = fields.Int()
    date = fields.Date()
    src_ip = fields.Str()
    dest_port_count = fields.Int()
    alert_classification = fields.Str() 
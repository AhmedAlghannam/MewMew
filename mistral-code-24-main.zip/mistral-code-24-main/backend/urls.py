from django.contrib import admin 
from django.urls import path
from django.http import HttpResponseRedirect
from views import *

urlpatterns = [ 
    path('admin/', admin.site.urls), 
    path('toptalkerssearch/', GetSourceIPs.as_view(), name="src_ips"), 
    path('destportsearch/', GetDestPort.as_view(), name="dest_port"),
    path('timesearch/', TimestampSearchView.as_view(), name='timesearch'),
    path('destporttable/', DestPortTopPacketsView.as_view(), name='dest_port_table'), 
    path('overview/', Overview.as_view(), name='overview'),
    path('ip_unique_dest_ports/', IpUniqueDestPortsView.as_view(), name='ip_unique_dest_ports'),
    path('alert-counts/', AlertCountsView.as_view(), name='alert_counts'),
    path('top-dest-ip-per-hour/', TopNDestIPPerHourView.as_view(), name='top_dest_ip'),
    path('authenticate/', Authenticate.as_view(), name="authenticate")
]
from datetime import date, datetime, time, timedelta
from venv import logger
from django.utils.timezone import now
from django.db.models.functions import ExtractHour
from django.db.models import Count
from pandas import Timestamp
import pytz
from rest_framework.views import APIView
from sqlalchemy import and_, create_engine, desc, func, label, or_, select, distinct
from models import *
from sqlalchemy.orm import aliased
from rest_framework.response import Response
from serializer import *
from dateutil import parser
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from sqlalchemy.sql import label, column
from rest_framework import status
from sqlalchemy.orm import sessionmaker
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views import View
from django.utils.timezone import make_aware
from datetime import datetime
from django.db import models
from urllib.parse import urlparse
from onelogin.saml2.auth import OneLogin_Saml2_Auth


# connect to SQL database
DATABASE_URL = 'sqlite:///example.db'
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)

class GetSourceIPs(APIView):
    def get(self, request):
        session = Session()
        try:
            returnedData = {}
            
            # extract data for the top ten sourceip graph
            masterQuery = session.query(DailySummary.src_ip, 
                                        func.sum(DailySummary.bytes).label('PacketsSummary.bytes'),
                                        func.count(DailySummary.src_ip).label('src_ip_count'))\
                .group_by(DailySummary.src_ip)\
                .all()
            
            allColumns = ["SourceIP.src_ip", 
                          "PacketsSummary.bytes", 
                          "src_ip_count"]
            
            # serialize each row through the schema and append to the large data frame
            serializedData = []
            
            for row in masterQuery:
                serializedRow = {}
                for i, column in enumerate(allColumns):
                    serializedRow[str(column)] = row[i]
            
                serializedData.append(serializedRow)
            
            returnedData["source_ip_ten"] = serializedData
            
            # create data for the top ten prot num graph; we also want how much each src-ip contributes to the prot num
            masterQuery = session.query(DailySummary.prot_num,
                                        func.count(DailySummary.prot_num).label('prot_count'))\
                .group_by(DailySummary.prot_num)\
                .all()
            
            allColumns = ["FlowSummary.prot_num", 
                          "prot_count"]
            
            # serialize each row through the schema and append to the large data frame
            serializedData = []
            for row in masterQuery:
                serializedRow = {}
                for i, column in enumerate(allColumns):
                    serializedRow[str(column)] = row[i]
            
                serializedData.append(serializedRow)
            
            returnedData["prot_ten"] = serializedData
            
            # create data for the sankey graph
            masterQuery = session.query(DailySummary.src_ip,
                                        DailySummary.dest_ip,
                                        func.sum(DailySummary.bytes).label('total_bytes')
                                    )\
                                    .group_by(
                                        DailySummary.src_ip,
                                        DailySummary.dest_ip
                                    )\
                                    .all()
            serializedData = []
            for row in masterQuery:
                serializedData.append({
                    'src_ip': row.src_ip,
                    'dst_ip': row.dest_ip,
                    'total_bytes': row.total_bytes
                })
            
            returnedData["dest_src_bytes"] = serializedData
            
            # create data for the flow vs. hour graph         
            masterQuery = session.query(DailySummary.hour, 
                                        func.count(DailySummary.hour).label('hour_count')
                                    )\
                                    .group_by(DailySummary.hour)\
                                    .all()
                                        
            serializedData = []
            for row in masterQuery:
                serializedData.append({
                    'hour': row.hour,
                    'hour_count': row.hour_count
                })  
            
            returnedData["flow_count"] = serializedData  
                    
            return Response(returnedData, status=status.HTTP_200_OK)
        except Exception as e:
            session.rollback()
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        finally:
            session.close()


class GetDestPort(APIView):

    @staticmethod
    def operatorToString(operator):
        operators = {
            "lt": "__lt__",
            "gt": "__gt__",
            "le": "__le__",
            "ge": "__ge__",
            "eq": "__eq__"
        }
        return operators.get(operator)

    def get(self, request):
            session = Session()
            
            columns = request.query_params["columnsComma"]
            columnsArray = columns.split(",")
            
            tableQueries = set()
            allQueries = []

            # determine which tables to query
            for tableColumn in columnsArray:
                table, column = tableColumn.split('.')
                tableQueries.add(table)
                allQueries.append(getattr(globals().get(table), column))

            joinQuery = session.query(*allQueries)
            
            groupQueries = []
            groupJoinParameters = []
            for group, values in list(request.query_params.items())[:-1]:
                
                valueArray = values.split(',')
                i = 0
                
                # FOR EACH GROUP, add the join
                groupJoinParameters.append(group[1:])
                
                # FOR EACH GROUP, add all of our filter queries into the filterQueries array (individual)
                filterQueries = []
                joinParameters = []
                
                while i < len(valueArray):
                    tableName, fieldParameter = valueArray[i].split('.')
                    value = valueArray[i+1]
                    operation = valueArray[i+2]
                    
                    tableQueries.add(tableName)

                    column = getattr(globals().get(tableName), fieldParameter, None)
                    filterQuery = getattr(column, self.operatorToString(operation))(value)

                    if i == 0:
                        filterQueries.append(filterQuery)
                        # print(list(filterQueries))
                    else:
                        join = valueArray[i+3]
                        joinParameters.append(join)
                        filterQueries.append(filterQuery)
                        i += 1
                    
                    i += 3
                
                # FOR EACH GROUP, combine these queries through the join operator
                if filterQueries:
                    combinedFilter = filterQueries[0]
                    for j in range(1, len(filterQueries)):
                        if joinParameters[j-1] == "AND":
                            combinedFilter = combinedFilter & filterQueries[j]
                        elif joinParameters[j-1] == "OR":
                            combinedFilter = combinedFilter | filterQueries[j]
                            
                            
                # FOR EACH GROUP, go ahead and do the filter
                groupQueries.append(combinedFilter)
                
            if "SourceIP" in tableQueries:
                joinQuery = joinQuery.add_columns(FlowSummary.src_id, SourceIP.id).join(SourceIP, FlowSummary.src_id == SourceIP.id)

            if "DestinationIP" in tableQueries:
                joinQuery = joinQuery.add_columns(FlowSummary.dest_id, DestinationIP.id).join(DestinationIP, FlowSummary.dest_id == DestinationIP.id)
                
            if "TimeStamps" in tableQueries:
                joinQuery = joinQuery.add_columns(FlowSummary.key, TimeStamps.flow_id).join(TimeStamps, FlowSummary.key == TimeStamps.flow_id)
                
            if "PacketsSummary" in tableQueries:
                joinQuery = joinQuery.add_columns(FlowSummary.key, PacketsSummary.flow_id).join(PacketsSummary, FlowSummary.key == PacketsSummary.flow_id)

            
            joinQueryCombined = joinQuery.filter(groupQueries[0])
            for i in range(1, len(groupJoinParameters)):
                if(groupJoinParameters[i] == "AND"):
                    joinQueryCombined = joinQueryCombined.filter(groupQueries[i])
                elif (groupJoinParameters[i] == "OR"):
                    tempJoinQuery = joinQuery.filter(groupQueries[i])
                    joinQueryCombined = joinQueryCombined.union_all(tempJoinQuery)
                    
            # Execute query and cleanup
            masterQuery = joinQueryCombined.all()
            session.close()
            
            # serialize each row through the schema and append to the large data frame
            serializedData = []
    
            for row in masterQuery:
                serializedRow = {}
                for i, column in enumerate(allQueries):
                    serializedRow[str(column)] = row[i]
                
                serializedData.append(serializedRow)
                
            return Response(serializedData, status=status.HTTP_200_OK)
        
class SourceIPSearchView(APIView):
    def get(self, request):
        session = Session()
        
        srcIpQuery = request.query_params.get('src_ip', None)
        
        if srcIpQuery:
            # create the queries
            joinCondition = FlowSummary.key == TimeStamps.flow_id
            srcIps = session.query(FlowSummary, TimeStamps, SourceIP, DestinationIP)\
                            .join(TimeStamps, joinCondition)\
                            .join(SourceIP, FlowSummary.src_id == SourceIP.id)\
                            .join(DestinationIP, FlowSummary.dest_id == DestinationIP.id)\
                            .filter(SourceIP.src_ip == srcIpQuery)\
                            .all()
            session.close()
            
            # create schema to serialize these tables (tools to turn these tables into Python dictionaries)
            flowSummarySerializer = FlowSummarySchema()
            timeStampSerializer = TimeStampsSchema()
            srcipSerializer = SourceIPSchema()
            destipSerializer = DestinationIPSchema()
            
            # serialize each row through the schema and append to the large data frame
            serializedData = []
            for flowSummary, timeStamp, sourceIP, destinationIP in srcIps:
                
                flowSummarySerialized = flowSummarySerializer.dump(flowSummary)
                timeStampSerialized = timeStampSerializer.dump(timeStamp)
                srcipSerialized = srcipSerializer.dump(sourceIP)
                destinationipSerialized = destipSerializer.dump(destinationIP)
                
                row = {
                    'FlowSummary': flowSummarySerialized,
                    'TimeStamps': timeStampSerialized,
                    'SourceIP': srcipSerialized,
                    'DestinationIP': destinationipSerialized
                }
                
                serializedData.append(row)
                
            return Response(serializedData, status=status.HTTP_200_OK)
        
        session.close()
        
        
class PacketsSummarySearchView(APIView):
    def get(self, request):
        src_ip_query = request.query_params.get('src_ip')
        dest_ip_query = request.query_params.get('dest_ip')
        session = Session()

        if src_ip_query and dest_ip_query:
            packets = session.query(PacketsSummary, FlowSummary, SourceIP, DestinationIP)\
                                .join(FlowSummary, PacketsSummary.flow_id == FlowSummary.key)\
                                .join(SourceIP, FlowSummary.src_id == SourceIP.id)\
                                .join(DestinationIP, FlowSummary.dest_id == DestinationIP.id)\
                                .filter(SourceIP.src_ip == src_ip_query, DestinationIP.dest_ip == dest_ip_query)\
                                .all()

            # Create schema to serialize rows
            packetsSummarySerializer = PacketsSummarySchema()
            flowSummarySerializer = FlowSummarySchema()
            srcipSerializer = SourceIPSchema()
            destipSerializer = DestinationIPSchema()
            
            serializedData = []
            for packet, flowSummary, sourceIP, destinationIP in packets:
                packetsSummarySerialized = packetsSummarySerializer.dump(packet)
                flowSummarySerialized = flowSummarySerializer.dump(flowSummary)
                srcipSerialized = srcipSerializer.dump(sourceIP)
                destipSerialized = destipSerializer.dump(destinationIP)
                
                row = {
                    'packetsSummary': packetsSummarySerialized,
                    'flowSummary': flowSummarySerialized,
                    'srcIP': srcipSerialized,
                    'destIP': destipSerialized
                }
                
                serializedData.append(row)
                
            return Response(serializedData, status=status.HTTP_200_OK)
        
class Overview(APIView):
    def get(self, request):
        session = Session()
        try:
            # Extract the date and hour ranges from the query
            startDate = request.query_params.get('startDate')
            endDate = request.query_params.get('endDate')
            startHour = request.query_params.get('startHour')
            endHour = request.query_params.get('endHour')
            data_type = request.query_params.get('type')
            count_param = request.query_params.get('count', '5')

            startHour = int(startHour.split(':')[0])
            endHour = int(endHour.split(':')[0])
            top_count = int(count_param)

            serialized_data = []
            if data_type == 'src_ip':
                top_src_ips_query = session.query(
                    TimeStamps.date,
                    TimeStamps.hour,
                    SourceIP.src_ip,
                    func.count(SourceIP.src_ip).label('total')
                ).join(
                    FlowSummary, TimeStamps.flow_id == FlowSummary.key
                ).join(
                    SourceIP, FlowSummary.src_id == SourceIP.id
                ).filter(
                    TimeStamps.date.between(startDate, endDate),
                    TimeStamps.hour >= startHour,
                    TimeStamps.hour <= endHour
                ).group_by(
                    TimeStamps.date, TimeStamps.hour, SourceIP.src_ip
                ).order_by(
                    TimeStamps.date, TimeStamps.hour, func.count(SourceIP.src_ip).desc()
                ).all()

                top_src_ips_dict = {}

                for row in top_src_ips_query:
                    key = (row.date, row.hour)
                    if key not in top_src_ips_dict:
                        top_src_ips_dict[key] = []
                    top_src_ips_dict[key].append({'src_ip': row.src_ip, 'total': row.total})

                for key in top_src_ips_dict:
                    hour_data = {'date': key[0], 'hour': key[1]}
                    top_src_ips = top_src_ips_dict[key]
                    top_n_src_ips = top_src_ips[:top_count]
                    other_total = sum([ip['total'] for ip in top_src_ips[top_count:]])
                    hour_data['top_src_ips'] = top_n_src_ips
                    hour_data['other'] = other_total
                    serialized_data.append(hour_data)

            elif data_type == 'dest_ip':
                top_dest_ips_query = session.query(
                    TimeStamps.date,
                    TimeStamps.hour,
                    DestinationIP.dest_ip,
                    func.count(DestinationIP.dest_ip).label('total')
                ).join(
                    FlowSummary, TimeStamps.flow_id == FlowSummary.key
                ).join(
                    DestinationIP, FlowSummary.dest_id == DestinationIP.id
                ).filter(
                    TimeStamps.date.between(startDate, endDate),
                    TimeStamps.hour >= startHour,
                    TimeStamps.hour <= endHour
                ).group_by(
                    TimeStamps.date, TimeStamps.hour, DestinationIP.dest_ip
                ).order_by(
                    TimeStamps.date, TimeStamps.hour, func.count(DestinationIP.dest_ip).desc()
                ).all()

                top_dest_ips_dict = {}

                for row in top_dest_ips_query:
                    key = (row.date, row.hour)
                    if key not in top_dest_ips_dict:
                        top_dest_ips_dict[key] = []
                    top_dest_ips_dict[key].append({'dest_ip': row.dest_ip, 'total': row.total})

                for key in top_dest_ips_dict:
                    hour_data = {'date': key[0], 'hour': key[1]}
                    top_dest_ips = top_dest_ips_dict[key]
                    top_n_dest_ips = top_dest_ips[:top_count]
                    other_total = sum([ip['total'] for ip in top_dest_ips[top_count:]])
                    hour_data['top_dest_ips'] = top_n_dest_ips
                    hour_data['other'] = other_total
                    serialized_data.append(hour_data)

            elif data_type == 'destport':
                top_dest_ports_query = session.query(
                    TimeStamps.date,
                    TimeStamps.hour,
                    FlowSummary.dest_port,
                    func.count(FlowSummary.dest_port).label('total')
                ).join(
                    FlowSummary, TimeStamps.flow_id == FlowSummary.key
                ).filter(
                    TimeStamps.date.between(startDate, endDate),
                    TimeStamps.hour >= startHour,
                    TimeStamps.hour <= endHour
                ).group_by(
                    TimeStamps.date, TimeStamps.hour, FlowSummary.dest_port
                ).order_by(
                    TimeStamps.date, TimeStamps.hour, func.count(FlowSummary.dest_port).desc()
                ).all()

                top_dest_ports_dict = {}

                for row in top_dest_ports_query:
                    key = (row.date, row.hour)
                    if key not in top_dest_ports_dict:
                        top_dest_ports_dict[key] = []
                    top_dest_ports_dict[key].append({'dest_port': row.dest_port, 'total': row.total})

                for key in top_dest_ports_dict:
                    hour_data = {'date': key[0], 'hour': key[1]}
                    top_dest_ports = top_dest_ports_dict[key]
                    top_n_dest_ports = top_dest_ports[:top_count]
                    other_total = sum([port['total'] for port in top_dest_ports[top_count:]])
                    hour_data['top_dest_ports'] = top_n_dest_ports
                    hour_data['other'] = other_total
                    serialized_data.append(hour_data)

            elif data_type == 'packets':
                data_query = session.query(
                    TimeStamps.date,
                    TimeStamps.hour,
                    func.sum(PacketsSummary.packets).label('total_packets')
                ).join(PacketsSummary, TimeStamps.flow_id == PacketsSummary.flow_id
                ).filter(
                    TimeStamps.date.between(startDate, endDate),
                    TimeStamps.hour >= startHour,
                    TimeStamps.hour <= endHour
                ).group_by(
                    TimeStamps.date, TimeStamps.hour
                ).all()

                data_dict = {(date, hour): total_packets for date, hour, total_packets in data_query}
                serialized_data = [
                    {'date': date, 'hour': hour, 'total_packets': data_dict.get((date, hour), 0)}
                    for date, hour in data_dict.keys()
                ]
            else:  # data_type == 'octets'
                data_query = session.query(
                    TimeStamps.date,
                    TimeStamps.hour,
                    func.sum(PacketsSummary.bytes).label('total_bytes')
                ).filter(
                    TimeStamps.date.between(startDate, endDate),
                    TimeStamps.hour >= startHour,
                    TimeStamps.hour <= endHour
                ).join(PacketsSummary, TimeStamps.flow_id == PacketsSummary.flow_id
                ).group_by(
                    TimeStamps.date, TimeStamps.hour
                ).all()

                data_dict = {(date, hour): total_bytes for date, hour, total_bytes in data_query}
                serialized_data = [
                    {'date': date, 'hour': hour, 'total_bytes': data_dict.get((date, hour), 0)}
                    for date, hour in data_dict.keys()
                ]

            return Response(serialized_data, status=status.HTTP_200_OK)

        except ValueError as ve:
            logger.error(f"Value error: {ve}")
            return Response({'error': str(ve)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error(f"Internal server error: {e}")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        finally:
            session.close()

class TopNDestIPPerHourView(APIView):
    def get(self, request):
        date_query = request.query_params.get('date')
        count_query = request.query_params.get('count', 10)  # Default to 10 if not provided
        session = Session()

        if date_query is not None:
            try:
                # Parse the date from the query parameters
                date = datetime.strptime(date_query, '%Y-%m-%d').date()
                count = int(count_query)

                # Define Eastern Time Zone
                eastern = pytz.timezone('America/New_York')

                # Determine the start and end times in Eastern Time
                start_time = eastern.localize(datetime.combine(date, time.min))
                end_time = start_time + timedelta(days=1)

                # Use a window function to rank entries within each hour group
                rank = label('rank', func.rank().over(
                    partition_by=TimeStamps.hour,
                    order_by=desc(PacketsSummary.bytes)
                ))

                # Subquery to rank entries
                subquery = session.query(
                    PacketsSummary.id.label('packets_summary_id'),
                    DestinationIP.id.label('destination_ip_id'),
                    TimeStamps.hour.label('hour'),
                    rank
                ).join(
                    FlowSummary, PacketsSummary.flow_id == FlowSummary.key
                ).join(
                    DestinationIP, FlowSummary.dest_id == DestinationIP.id
                ).join(
                    TimeStamps, PacketsSummary.flow_id == TimeStamps.flow_id  # Ensure correct join condition
                ).filter(
                    TimeStamps.date == date
                ).subquery()

                # Main query to get top N destination IPs for each hour
                top_dest_ips = session.query(
                    PacketsSummary,
                    DestinationIP,
                    subquery.c.hour
                ).join(
                    subquery, PacketsSummary.id == subquery.c.packets_summary_id
                ).join(
                    DestinationIP, subquery.c.destination_ip_id == DestinationIP.id
                ).filter(
                    subquery.c.rank <= count
                ).order_by(
                    subquery.c.hour,
                    subquery.c.rank
                ).all()

                # Create schema to serialize rows
                packetsSummarySerializer = PacketsSummarySchema()
                destipSerializer = DestinationIPSchema()

                serializedData = []
                for packet, destinationIP, hour in top_dest_ips:
                    packetsSummarySerialized = packetsSummarySerializer.dump(packet)
                    destipSerialized = destipSerializer.dump(destinationIP)

                    row = {
                        'hour': hour,
                        'packetsSummary': packetsSummarySerialized,
                        'destIP': destipSerialized
                    }

                    serializedData.append(row)

                return Response(serializedData, status=status.HTTP_200_OK)

            except ValueError as ve:
                return Response({'error': 'Invalid date format'}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                return Response({'error': 'Internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            return Response({'error': 'Date parameter is required'}, status=status.HTTP_400_BAD_REQUEST)


class TimestampSearchView(APIView):
    def get(self, request):
        date_query = request.query_params.get('date')
        count_query = request.query_params.get('count', 10)  # Default to 10 if not provided
        session = Session()

        if date_query is not None:
            try:
                # Parse the date from the query parameters
                date = datetime.strptime(date_query, '%Y-%m-%d').date()
                count = int(count_query)

                # Define Eastern Time Zone
                eastern = pytz.timezone('America/New_York')

                # Determine the start and end times in Eastern Time
                start_time = eastern.localize(datetime.combine(date, time.min))
                end_time = start_time + timedelta(days=1)

                # Use a window function to rank entries within each hour group
                rank = label('rank', func.rank().over(
                    partition_by=TimeStamps.hour,
                    order_by=desc(PacketsSummary.bytes)
                ))

                # Subquery to rank entries
                subquery = session.query(
                    PacketsSummary.id.label('packets_summary_id'),
                    FlowSummary.key.label('flow_summary_key'),  # Assuming 'key' is the primary key for FlowSummary
                    SourceIP.id.label('source_ip_id'),
                    DestinationIP.id.label('destination_ip_id'),
                    TimeStamps.hour.label('hour'),
                    rank
                ).join(
                    FlowSummary, PacketsSummary.flow_id == FlowSummary.key
                ).join(
                    SourceIP, FlowSummary.src_id == SourceIP.id
                ).join(
                    DestinationIP, FlowSummary.dest_id == DestinationIP.id
                ).join(
                    TimeStamps, PacketsSummary.flow_id == TimeStamps.flow_id  # Ensure correct join condition
                ).filter(
                    TimeStamps.date == date
                ).subquery()

                # Main query to get top N packets for each hour
                top_packets = session.query(
                    PacketsSummary,
                    FlowSummary,
                    SourceIP,
                    DestinationIP,
                    subquery.c.hour
                ).join(
                    subquery, PacketsSummary.id == subquery.c.packets_summary_id
                ).join(
                    FlowSummary, PacketsSummary.flow_id == FlowSummary.key
                ).join(
                    SourceIP, FlowSummary.src_id == SourceIP.id
                ).join(
                    DestinationIP, FlowSummary.dest_id == DestinationIP.id
                ).filter(
                    subquery.c.rank <= count
                ).order_by(
                    subquery.c.hour,
                    subquery.c.rank
                ).all()

                # Create schema to serialize rows
                packetsSummarySerializer = PacketsSummarySchema()
                flowSummarySerializer = FlowSummarySchema()
                srcipSerializer = SourceIPSchema()
                destipSerializer = DestinationIPSchema()

                serializedData = []
                for packet, flowSummary, sourceIP, destinationIP, hour in top_packets:
                    packetsSummarySerialized = packetsSummarySerializer.dump(packet)
                    flowSummarySerialized = flowSummarySerializer.dump(flowSummary)
                    srcipSerialized = srcipSerializer.dump(sourceIP)
                    destipSerialized = destipSerializer.dump(destinationIP)

                    row = {
                        'hour': hour,
                        'packetsSummary': packetsSummarySerialized,
                        'flowSummary': flowSummarySerialized,
                        'srcIP': srcipSerialized,
                        'destIP': destipSerialized
                    }

                    serializedData.append(row)

                return Response(serializedData, status=status.HTTP_200_OK)

            except ValueError as ve:
                logger.error(f"ValueError: {ve}")
                return Response({'error': 'Invalid date format'}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                logger.error(f"Exception: {e}")
                logger.error(f"Error details: {str(e)}")
                return Response({'error': 'Internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            logger.error("Date parameter is required")
            return Response({'error': 'Date parameter is required'}, status=status.HTTP_400_BAD_REQUEST)


class DestPortTopPacketsView(APIView):
    def get(self, request):
        date_query = request.query_params.get('date')
        count_query = request.query_params.get('count', 10)  # Default to 10 if not provided
        session = Session()

        if date_query is not None:
            try:
                # Parse the date from the query parameters
                date = datetime.strptime(date_query, '%Y-%m-%d').date()
                count = int(count_query)

                # Define Eastern Time Zone
                eastern = pytz.timezone('America/New_York')

                # Determine the start and end times in Eastern Time
                start_time = eastern.localize(datetime.combine(date, time.min))
                end_time = start_time + timedelta(days=1)

                logger.info(f"Fetching data from {start_time} to {end_time} limited to top {count} dest ports per hour")

                # Use a window function to rank entries within each hour group
                rank = label('rank', func.rank().over(
                    partition_by=[TimeStamps.date, TimeStamps.hour],
                    order_by=desc(PacketsSummary.bytes)
                ))

                # Subquery to rank entries
                subquery = session.query(
                    PacketsSummary.id.label('packets_summary_id'),
                    FlowSummary.key.label('flow_summary_key'),  # Assuming 'key' is the primary key for FlowSummary
                    SourceIP.id.label('source_ip_id'),
                    DestinationIP.id.label('destination_ip_id'),
                    FlowSummary.dest_port.label('dest_port'),
                    TimeStamps.date.label('date'),
                    TimeStamps.hour.label('hour'),
                    rank
                ).join(
                    FlowSummary, PacketsSummary.flow_id == FlowSummary.key
                ).join(
                    SourceIP, FlowSummary.src_id == SourceIP.id
                ).join(
                    DestinationIP, FlowSummary.dest_id == DestinationIP.id
                ).join(
                    TimeStamps, PacketsSummary.flow_id == TimeStamps.flow_id  # Ensure correct join condition
                ).filter(
                    TimeStamps.date == date
                ).subquery()

                logger.debug(f"Subquery: {str(subquery)}")

                # Main query to get top N packets for each hour
                top_packets = session.query(
                    PacketsSummary,
                    subquery.c.date,
                    subquery.c.hour,
                    subquery.c.dest_port,
                    FlowSummary,
                    SourceIP,
                    DestinationIP
                ).join(
                    subquery, PacketsSummary.id == subquery.c.packets_summary_id
                ).join(
                    FlowSummary, PacketsSummary.flow_id == FlowSummary.key
                ).join(
                    SourceIP, FlowSummary.src_id == SourceIP.id
                ).join(
                    DestinationIP, FlowSummary.dest_id == DestinationIP.id
                ).filter(
                    subquery.c.rank <= count
                ).order_by(
                    subquery.c.date,
                    subquery.c.hour,
                    subquery.c.rank
                ).all()

                logger.info(f"Fetched {len(top_packets)} top packets")

                # Create schema to serialize rows
                packetsSummarySerializer = PacketsSummarySchema()
                flowSummarySerializer = FlowSummarySchema()
                srcipSerializer = SourceIPSchema()
                destipSerializer = DestinationIPSchema()

                serializedData = []
                for packet, date, hour, dest_port, flowSummary, sourceIP, destinationIP in top_packets:
                    packetsSummarySerialized = packetsSummarySerializer.dump(packet)
                    flowSummarySerialized = flowSummarySerializer.dump(flowSummary)
                    srcipSerialized = srcipSerializer.dump(sourceIP)
                    destipSerialized = destipSerializer.dump(destinationIP)

                    row = {
                        'date': date,
                        'hour': hour,
                        'dest_port': dest_port,
                        'packetsSummary': [packetsSummarySerialized],
                        'flowSummary': flowSummarySerialized,
                        'srcIP': srcipSerialized,
                        'destIP': destipSerialized
                    }

                    serializedData.append(row)

                return Response(serializedData, status=status.HTTP_200_OK)

            except ValueError as ve:
                logger.error(f"ValueError: {ve}")
                return Response({'error': 'Invalid date format'}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                logger.error(f"Exception: {e}")
                logger.error(f"Error details: {str(e)}")
                return Response({'error': 'Internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            logger.error("Date parameter is required")
            return Response({'error': 'Date parameter is required'}, status=status.HTTP_400_BAD_REQUEST)

        
class Authenticate(APIView):
    def get(self, request):
        net_id = request.META['HTTP_UID']
        new_user = User(net_id=net_id)
        
        # check if the netID exists in the database
        session = Session()
        user = session.query(User).filter_by(net_id=net_id).first()

        if not user:
            # if the user does not exist, add it to the database
            new_user = User(net_id=net_id)
            session.add(new_user)
            session.commit()

                # update the session to include the user's netID
                #request.session['user'] = net_id
        session.close()
                
        frontend_redirect_url = "http://localhost:4000/app/dashboard"
        return HttpResponseRedirect(frontend_redirect_url)
    
class IpUniqueDestPortsView(APIView):
    def get(self, request):
        session = Session()
        date_param = request.query_params.get('date', None)

        eastern = pytz.timezone('US/Eastern')
        
        today_utc = datetime.utcnow()
        today_eastern = today_utc.astimezone(eastern).date()
        
        three_days_ago = today_eastern - timedelta(days=3)
        
        if date_param:
            selected_date = datetime.strptime(date_param, '%Y-%m-%d').date()
            ip_unique_dest_ports = session.query(IpUniqueDestPorts).filter(
                IpUniqueDestPorts.date == selected_date
            ).all()
        else:
            ip_unique_dest_ports = session.query(IpUniqueDestPorts).filter(
                IpUniqueDestPorts.date.between(three_days_ago, today_eastern)
            ).all()
        
        session.close()

        schema = IpUniqueDestPortsSchema(many=True)
        return Response(schema.dump(ip_unique_dest_ports), status=status.HTTP_200_OK)

    
class AlertCountsView(APIView):
    def get(self, request):
        session = Session()
        
        eastern = pytz.timezone('US/Eastern')

        today_utc = datetime.utcnow()
        today_eastern = today_utc.astimezone(eastern).date()
        
        total_alerts = session.query(IpUniqueDestPorts).filter(
            IpUniqueDestPorts.date == today_eastern, 
            IpUniqueDestPorts.alert_classification.in_(['High', 'Medium', 'Low'])).count()
        high_alerts = session.query(IpUniqueDestPorts).filter(
            IpUniqueDestPorts.date == today_eastern, IpUniqueDestPorts.alert_classification == 'High').count()
        medium_alerts = session.query(IpUniqueDestPorts).filter(
            IpUniqueDestPorts.date == today_eastern, IpUniqueDestPorts.alert_classification == 'Medium').count()
        low_alerts = session.query(IpUniqueDestPorts).filter(
            IpUniqueDestPorts.date == today_eastern, IpUniqueDestPorts.alert_classification == 'Low').count()

        session.close()

        counts = {
            'total_alerts': total_alerts,
            'high_alerts': high_alerts,
            'medium_alerts': medium_alerts,
            'low_alerts': low_alerts
        }

        return Response(counts, status=status.HTTP_200_OK)

from models import DailySummary
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime

# session setup
engine = create_engine('sqlite:///example.db')
SessionLocal = sessionmaker(bind=engine)

session = SessionLocal()

datetime.now().date()
previousData = session.query(DailySummary)\
                    .filter(DailySummary.date != datetime.now().date())
previousData.delete(synchronize_session='fetch')

session.commit()
session.close()

import React from 'react';
import './teams.css';
import cisco from '../images/cisco.png';
import nsf from '../images/nsf.png';
import oit from '../images/oit.png';
import sophie from '../images/sophie.png';
import roudy from '../images/roudy.png';
import joanne from '../images/joanne.png';
import emily from '../images/emily.png';
import kevin from '../images/kevin.png';
import alex from '../images/alex.png';
import eric from '../images/eric.png';
import spiral from '../images/spiral.png';
import arrowIcon from '../images/arrow.png';
import Footer from "./footer.js";
import TransparentNavBar from "./transparentnavbar.js";


const Teams = () => {
  return (
    <>
      <TransparentNavBar />
      <div className="teams-container">
        <img src={spiral} alt="spiral" className="spiral-img" />
        <section className="teams-header">
          <h2>Meet the Team</h2>
          <hr />
        </section>

        <section className="section section-1">
          <h3>Students</h3>
          <div className="team-members">
            <div className="member">
              <div className="avatar">
                <img src={sophie} alt="Sophie Mansoor" />
              </div>
              <p>Sophie Mansoor</p>
            </div>
            <div className="member">
              <div className="avatar">
                <img src={roudy} alt="Roudy Mohamed" />
              </div>
              <p>Roudy Mohamed</p>
            </div>
            <div className="member">
              <div className="avatar">
                <img src={joanne} alt="Joanne Chae" />
              </div>
              <p>Joanne Chae</p>
            </div>
            <div className="member">
              <div className="avatar">
                <img src={emily} alt="Emily Barragan" />
              </div>
              <p>Emily Barragan</p>
            </div>
            <div className="member">
              <div className="avatar">
                <img src={kevin} alt="Kevin Lee" />
              </div>
              <p>Kevin Lee</p>
            </div>
          </div>
        </section>

        <section className="section section-2">
          <h3>Team Leaders</h3>
          <div className="team-leaders">
            <div className="leader">
              <div className="avatar">
                <img src={alex} alt="Alexander Merck" />
              </div>
              <p>Alexander Merck</p>
            </div>
            <div className="leader">
              <div className="avatar">
                <img src={eric} alt="Eric Hope" />
              </div>
              <p>Eric Hope</p>
            </div>
          </div>
         </section>
  
        <section className="section section-3">
          <h3>Sponsors</h3>
          <hr />
          <div className="project-sponsors">
            <div className="sponsor-card">
              <div className="sponsor-image">
                <img src={cisco} alt="Cisco" />
                <div className="teams-overlay">
                  <a href="https://www.cisco.com" target="_blank" rel="noopener noreferrer">
                    Visit CISCO Website 
                    <img src={arrowIcon} alt="Arrow" className="arrow-icon" />
                  </a>
                </div>
              </div>
            </div>
            <div className="sponsor-card">
              <div className="sponsor-image">
                <img src={nsf} alt="NSF" />
                <div className="teams-overlay">
                  <a href="https://www.nsf.gov" target="_blank" rel="noopener noreferrer">
                    Visit NSF Website
                    <img src={arrowIcon} alt="Arrow" className="arrow-icon" />
                  </a>
                </div>
              </div>
            </div>
            <div className="sponsor-card">
              <div className="sponsor-image">
                <img src={oit} alt="Duke OIT" />
                <div className="teams-overlay">
                  <a href="https://www.oit.duke.edu" target="_blank" rel="noopener noreferrer">
                    Visit Duke OIT Website
                    <img src={arrowIcon} alt="Arrow" className="arrow-icon" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <div className="footer-teams">
        <Footer />
      </div>
    </>
  );
}

export default Teams;
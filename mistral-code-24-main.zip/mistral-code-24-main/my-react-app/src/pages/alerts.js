import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './alerts.css';
import DashboardNav from './dashboardNav.js';
import Footer from './footer.js';
import InfoModal from './infoalerts';
import infoIcon from '../images/info-icon.png'; 

const Alerts = () => {
    const [alerts, setAlerts] = useState([]);
    const [filter, setFilter] = useState('all');
    const [date, setDate] = useState('');
    const [searchIP, setSearchIP] = useState('');
    const [noAlerts, setNoAlerts] = useState(false);
    const [showModal, setShowModal] = useState(false); 

    useEffect(() => {
        fetchAlerts();
    }, [filter, date, searchIP]);

    const fetchAlerts = async () => {
        try {
            let url = '/api/ip_unique_dest_ports/';
            if (date) {
                url += `?date=${date}`;
            }

            const response = await axios.get(url);
            let filteredAlerts = response.data;

            if (filter !== 'all') {
                filteredAlerts = filteredAlerts.filter(alert => alert.alert_classification === filter);
            } else {
                filteredAlerts = filteredAlerts.filter(alert => 
                    alert.alert_classification === 'High' || 
                    alert.alert_classification === 'Medium' || 
                    alert.alert_classification === 'Low'
                );
            }

            if (date) {
                filteredAlerts = filteredAlerts.filter(alert => alert.date === date);
            }

            if (searchIP) {
                const searchResults = filteredAlerts.filter(alert => alert.src_ip.includes(searchIP));
                if (searchResults.length === 0) {
                    setNoAlerts(true);
                } else {
                    setNoAlerts(false);
                    filteredAlerts = searchResults;
                }
            } else {
                setNoAlerts(false);
            }

            filteredAlerts.sort((a, b) => b.p_value - a.p_value);

            setAlerts(filteredAlerts);
        } catch (error) {
            console.error('Error fetching alerts:', error);
        }
    };

    const formatPercentage = (value) => {
        return (value * 100).toPrecision(8) + '%';
    };

    const handleInfoClick = () => {
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };

    return (
        <div>
            <DashboardNav />
            <div className="alerts-container">
                <div className="alerts-main">
                    <div className="alerts-controls">
                        <div className="alerts-date-search">
                            <div className="alerts-date">
                                <label htmlFor="date">Choose Date: </label>
                                <input
                                    type="date"
                                    id="date"
                                    value={date}
                                    onChange={(e) => setDate(e.target.value)}
                                />
                            </div>
                            <div className="alerts-search">
                                <label htmlFor="searchIP">Search Source IP: </label>
                                <input
                                    type="text"
                                    id="searchIP"
                                    value={searchIP}
                                    onChange={(e) => setSearchIP(e.target.value)}
                                />
                            </div>
                            <img src={infoIcon} alt="Info" className="info-icon" onClick={handleInfoClick} />
                        </div>
                        <div className="alerts-buttons">
                            <button onClick={() => setFilter('all')}>All Alerts</button>
                            <button onClick={() => setFilter('High')}>High Alerts</button>
                            <button onClick={() => setFilter('Medium')}>Medium Alerts</button>
                            <button onClick={() => setFilter('Low')}>Low Alerts</button>
                        </div>
                    </div>
                    {noAlerts ? (
                        <p>No alerts found for the specified source IP.</p>
                    ) : (
                        <div className="alerts-table-container">
                            <div className="alerts-mainTable">
                                <table className="alerts-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Source IP</th>
                                            <th>Model Probability Prediction</th>
                                            <th>Alert Classification</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {alerts.map((alert, index) => (
                                            <tr key={index}>
                                                <td>{alert.date}</td>
                                                <td>{alert.src_ip}</td>
                                                <td>{formatPercentage(alert.p_value)}</td>
                                                <td className={`alerts-classification ${alert.alert_classification.toLowerCase()}`}>
                                                    {alert.alert_classification}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            <Footer />
            <InfoModal show={showModal} handleClose={handleCloseModal} />
        </div>
    );
};

export default Alerts;
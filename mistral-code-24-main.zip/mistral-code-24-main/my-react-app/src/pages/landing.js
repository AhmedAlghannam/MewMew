import React, { useEffect, useRef } from "react";
import "./landing.css";
import landing1 from "../images/landing1.png";
import landing2 from "../images/landing2.png";
import landing3 from "../images/landing3.png";
import landing4 from "../images/landing4.png";
import blob from "../images/blob.png";
import blob2 from "../images/blob2.png";
import dots from "../images/dots.png";
import Footer from "./footer.js";
import TransparentNavBar from "./transparentnavbar.js";

const Landing = () => {
  return (
    <>
      <TransparentNavBar />
      <section className="main-section">
        <div className="dots1-image">
          <img src={dots} alt="dots" />
        </div>
        <div className="main-text">
          <h1>Filter Data Faster.</h1>
          <p>
            MISTRAL captures and analyzes network data<br />
            through manageable data visualizations and<br />
            queries for research labs.
          </p>
          <a 
            href="http://localhost:4000/app/dashboard" 
            className="sso-button"
          >
            SIGN IN WITH SSO
          </a>
        </div>
        <div className="main-img-container">
          <img src={landing1} alt="Main" className="main-image" />
          <img src={blob} alt="Blob" className="blob-image" />
        </div>
      </section>

      <section className="about1-section">
        <div className="about1-image">
          <img src={landing2} alt="About1 MISTRAL" />
        </div>
        <div className="about1-text">
          <h2>What is MISTRAL?</h2>
          <p>
            The Massive Internal System Traffic Research Analysis and Logging
            (MISTRAL) aims to develop and enhance an internal network monitoring
            infrastructure and data collection mechanisms. It establishes a
            comprehensive Reference Security Dataset (RSSD) along with a robust
            data pipeline and advanced analysis methodologies.
          </p>
        </div>
      </section>

      <section className="about2-section">
        <div className="about2-text">
          <h2>Why MISTRAL?</h2>
          <p>
            MISTRAL is an innovative security strategy specifically designed for
            research environments. It enhances and refines monitoring and detection
            methodologies to effectively protect research infrastructure from potential threats.
          </p>
        </div>
        <div className="about2-img-container">
            <img src={landing3} alt="About2 MISTRAL" className="about2-image" />
            <img src={blob2} alt="Blob" className="blob2" />
        </div>
      </section>

      <section className="about3-section">
        <div className="about3-img">
          <img src={landing4} alt="About3 MISTRAL"/>
        </div>
        <div className="about3-text">
          <h2>Our goals</h2>
          <div className="li1-container">
            <p>• Deliver datasets that researchers can use (showing what research traffic on the website looks like)</p>
          </div>
          <div className="li2-container">
            <p>• Protect research data from attackers</p>
          </div>
          <div className="li3-container">
            <p>• Identify traffic on the network that is good vs. bad and display it through a visualization data tool</p>
          </div>
        </div>
      </section>
      
      <div className="footer-landing">
        <Footer />
      </div>
    </>
  );
};

export default Landing;

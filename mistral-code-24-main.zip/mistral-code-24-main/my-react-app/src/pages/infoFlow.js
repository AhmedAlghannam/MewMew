import React from 'react';
import './infoFlow.css'; 

const InfoFlow = ({ show, handleClose }) => {
    return (
        <div className={`flow-modal ${show ? 'flow-show' : ''}`} onClick={handleClose}>
            <div className="flow-modal-content" onClick={e => e.stopPropagation()}>
                <span className="flow-modal-close" onClick={handleClose}>&times;</span>
                <h2>Flow Over Time</h2>
                <p>The flow chart displays the daily top 10 flows. </p>
            </div>
        </div>
    );
};

export default InfoFlow;

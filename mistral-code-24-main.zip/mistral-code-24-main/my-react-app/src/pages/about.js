import * as React from 'react';
import Grid from "@mui/material/Grid";
import backgroundImage from '../background.jpeg';
import mistralLogo from '../MISTRALBLUE.png';
import Link from '@mui/material/Link';
import Button from '@mui/material/Button';
import LockPersonIcon from '@mui/icons-material/LockPerson';
import { createTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';

//color palette theme
const theme = createTheme({
    palette: {
        primary: {
            light: '#757ce8',
            main: '#3f50b5',
            dark: '#002884',
            contrastText: '#fff',
      },
    },
  });



  
//creating the grid layout
const About = () => {
  return (
    <div> 
      <Grid container style = {{ minHeight: '100vh'}}>
        <Grid item xs={12} sm={6}>
            <img src={backgroundImage} 
            style = {{width: '100%', height: '100%', objectFit: 'cover'}} 
            alt="background image"
        />
        </Grid>
        <Grid 
        container 
        item xs={12} 
        sm={6} 
        alignItems="center" 
        direction="column" 
        style={{ padding: 20 }}
        >
        <div />
            <div>
                <div style={{ height: 300 }} />
                <Grid container justify = "center">
                    <img src ={mistralLogo} 
                    width={400} 
                    alt="logo" 
                    />
                </Grid>
                
                <div style={{ height: 50 }} />
                <Grid container justifyContent = "center">
                    <Button 
                        onClick={() => {
                            <Link href="https://shib.oit.duke.edu/idp/profile/SAML2/Unsolicited/SSO?providerId=http://securityanalytics-researchlabs&shire=http://localhost:8000"
                            >
                            </Link>
                        }}
                        sx ={{bgcolor: "primary.dark"}}
                        variant="contained" 
                        size="large"
                        startIcon={<LockPersonIcon />}>
                        Sign In With SSO
                    </Button>
                </Grid>
                
                <div style={{ height: 20 }} />
                <Grid container textAlign="center">
                    <Grid item xs>
                        <Link href="https://oit.duke.edu/help"
                            variant="body2">
                                Having trouble signing in?
                            </Link>
                    </Grid>
                </Grid>

            </div>
            <div />
        </Grid>
      </Grid>
    </div>
  );
};

export default About; 

/*<div className="home-sign-container"
                    alignItems="center"
                    style={{padding:10}}
                    >
                    <Link to="https://shib.oit.duke.edu/idp/profile/SAML2/Unsolicited/SSO?providerId=http://securityanalytics-researchlabs&shire=http://localhost:8000" 
                    className="sign-in">
                    Sign In: SSO
                    </Link>
                </div>
                <p className="help-text">For assistance please visit: <a href="https://oit.duke.edu/help">https://oit.duke.edu/help</a></p>
            */
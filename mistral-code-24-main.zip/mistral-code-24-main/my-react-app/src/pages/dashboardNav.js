import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './dashboardNav.css';
import mistralLogo from '../mistraltransparent.png';

const DashboardNav = () => {
  const [isLifted, setIsLifted] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsLifted(true);
      } else {
        setIsLifted(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <nav className={`dashboard-nav ${isLifted ? 'lifted' : ''}`}>
      <Link to="/">
        <img src={mistralLogo} alt='Mistral Logo' className='dashboardnav-logo' />
      </Link>
      <ul>
        <li>
          <Link to="/app/dashboard" className={`nav-link ${location.pathname === '/app/dashboard' ? 'active' : ''}`}>Dashboard</Link>
        </li>
        <li>
          <Link to="/app/visualizations" className={`nav-link ${location.pathname === '/app/visualizations' ? 'active' : ''}`}>Visualizations</Link>
        </li>
        <li>
          <Link to="/app/advancedsearch" className={`nav-link ${location.pathname === '/app/advancedsearch' ? 'active' : ''}`}>Search</Link>
        </li>
        <li>
          <Link to="/app/alerts" className={`nav-link ${location.pathname === '/app/alerts' ? 'active' : ''}`}>Alerts</Link>
        </li>
      </ul>
    </nav>
  );
};

export default DashboardNav;
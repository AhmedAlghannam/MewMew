import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title as ChartTitle, Tooltip, Legend } from 'chart.js';
import './overview.css';
import moment from 'moment-timezone';
import randomColor from 'randomcolor';
import DashboardNav from './dashboardNav.js';
import PacketsSummaryTable from './PacketsSummaryTable';
import TopDestPortsTable from './TopDestPortsTable';
import TopDestIPPerHourTable from './TopDestIPPerHourTable';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ChartTitle,
  Tooltip,
  Legend
);

const PacketsBarChart = () => {
  const [data, setData] = useState({
    labels: [],
    datasets: []
  });

  const [loading, setLoading] = useState(false);
  const [selectedMetric, setSelectedMetric] = useState('packets');
  const [selectedCount, setSelectedCount] = useState('5');
  const [startDate, setStartDate] = useState(moment().tz('America/New_York').format('YYYY-MM-DD'));
  const [endDate, setEndDate] = useState(moment().tz('America/New_York').format('YYYY-MM-DD'));
  const [startHour, setStartHour] = useState(moment().tz('America/New_York').format('HH:00'));
  const [endHour, setEndHour] = useState(moment().tz('America/New_York').format('HH:00'));
  const [showTable, setShowTable] = useState(false);

  useEffect(() => {
    fetchData();
  }, [startDate, endDate, startHour, endHour, selectedMetric, selectedCount]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:4000/api/overview/', {
        params: {
          startDate: startDate,
          endDate: endDate,
          startHour: startHour,
          endHour: endHour,
          type: selectedMetric,
          count: selectedCount
        }
      });

      let chartLabels = [];
      let chartData = [];

      if (['src_ip', 'dest_ip', 'destport'].includes(selectedMetric)) {
        const topData = {};

        response.data.forEach(entry => {
          const label = `${entry.date} ${String(entry.hour).padStart(2, '0')}`;
          chartLabels.push(label);
          topData[label] = entry;
        });

        const datasets = [];
        const colors = {};

        const ids = new Set();

        response.data.forEach(entry => {
          const metricKey = selectedMetric === 'src_ip' ? 'top_src_ips' : selectedMetric === 'dest_ip' ? 'top_dest_ips' : 'top_dest_ports';
          entry[metricKey].forEach(data => {
            const id = selectedMetric === 'src_ip' ? data.src_ip : selectedMetric === 'dest_ip' ? data.dest_ip : data.dest_port;
            ids.add(id);
          });
        });

        ids.forEach(id => {
          if (!colors[id]) {
            colors[id] = randomColor();
          }
          datasets.push({
            label: id,
            data: chartLabels.map(label => {
              const entry = topData[label];
              const metricKey = selectedMetric === 'src_ip' ? 'top_src_ips' : selectedMetric === 'dest_ip' ? 'top_dest_ips' : 'top_dest_ports';
              const found = entry[metricKey].find(d => {
                return selectedMetric === 'src_ip' ? d.src_ip === id : selectedMetric === 'dest_ip' ? d.dest_ip === id : d.dest_port === id;
              });
              return found ? found.total : 0;
            }),
            backgroundColor: colors[id],
            borderColor: colors[id].replace('0.6', '1'),
            borderWidth: 1,
            stack: 'Stack 0'
          });
        });

        datasets.push({
          label: 'Other',
          data: chartLabels.map(label => topData[label].other || 0),
          backgroundColor: randomColor({ luminosity: 'dark' }),
          borderColor: randomColor({ luminosity: 'dark' }).replace('0.6', '1'),
          borderWidth: 1,
          stack: 'Stack 0'
        });

        setData({
          labels: chartLabels,
          datasets
        });
      } else {
        response.data.forEach(entry => {
          const label = `${entry.date} ${String(entry.hour).padStart(2, '0')}`;
          chartLabels.push(label);
          if (selectedMetric === 'packets') {
            chartData.push(entry.total_packets);
          } else if (selectedMetric === 'octets') {
            chartData.push(entry.total_bytes);
          }
        });

        setData({
          labels: chartLabels,
          datasets: [{
            label: `${selectedMetric.charAt(0).toUpperCase() + selectedMetric.slice(1)} per Hour`,
            data: chartData,
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
            stack: 'Stack 0'
          }]
        });
      }

    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMetricChange = (metric) => {
    setSelectedMetric(metric);
    if (metric === 'src_ip' || metric === 'destport' || metric === 'dest_ip') {
      setShowTable(true);
    } else {
      setShowTable(false);
    }
  };

  return (
    <div>
      <DashboardNav />
      <div className="overview-body">
        <div className="overview-search-bar-container">
          <div className="date-type-selection-box">
            <div className="date-time-selection-row">
              <div className="date-time-selection">
                <p className="visualization-input-labels">Select Start Date:</p>
                <input
                  type="date"
                  id="start-date"
                  value={startDate}
                  onChange={(event) => setStartDate(event.target.value)}
                />
              </div>
              <div className="date-time-selection">
                <p className="visualization-input-labels">Select End Date:</p>
                <input
                  type="date"
                  id="end-date"
                  value={endDate}
                  onChange={(event) => setEndDate(event.target.value)}
                />
              </div>
              <div className="date-time-selection">
                <p className="visualization-input-labels">Select Start Hour:</p>
                <input
                  type="time"
                  id="start-hour"
                  value={startHour}
                  onChange={(event) => setStartHour(event.target.value)}
                />
              </div>
              <div className="date-time-selection">
                <p className="visualization-input-labels">Select End Hour:</p>
                <input
                  type="time"
                  id="end-hour"
                  value={endHour}
                  onChange={(event) => setEndHour(event.target.value)}
                />
              </div>
            </div>
            <div className="type-selection">
              <p className="visualization-input-labels">Select Graph Category:</p>
              <select value={selectedMetric} onChange={(e) => handleMetricChange(e.target.value)}>
                <option value="src_ip">Source IP</option>
                <option value="dest_ip">Destination IP</option>
                <option value="packets">Packets</option>
                <option value="destport">Destination Port</option>
                <option value="octets">Bytes</option>
              </select>
            </div>
            {(selectedMetric === 'src_ip' || selectedMetric === 'dest_ip' || selectedMetric === 'destport') && (
              <div className="count-selection">
                <p className="visualization-input-labels">Select Count:</p>
                <select value={selectedCount} onChange={(e) => setSelectedCount(e.target.value)}>
                  <option value="5">5</option>
                  <option value="10">10</option>
                  <option value="15">15</option>
                </select>
              </div>
            )}
          </div>
        </div>
        <div className="bar-chart-wrapper">
          <div className="bar-chart-container white-background">
            {loading ? (
              <p className="loading1">Loading....</p>
            ) : (
              <Bar
                data={data}
                options={{
                  responsive: true,
                  plugins: {
                    legend: { position: 'top' },
                    title: {
                      display: true,
                      text: selectedMetric === 'src_ip' ? `Top ${selectedCount} Source IPs` :
                            selectedMetric === 'dest_ip' ? `Top ${selectedCount} Destination IPs` :
                            selectedMetric === 'destport' ? `Top ${selectedCount} Destination Ports` :
                            `${selectedMetric.charAt(0).toUpperCase() + selectedMetric.slice(1)} per Hour`
                    }
                  },
                  scales: {
                    x: { title: { display: true, text: 'Day-Hour of the Day' } },
                    y: { title: { display: true, text: selectedMetric.charAt(0).toUpperCase() + selectedMetric.slice(1) } }
                  }
                }}
              />
            )}
          </div>
        </div>
        {showTable && selectedMetric === 'src_ip' && <PacketsSummaryTable date={startDate} hour={new Date().getHours()} count={selectedCount} />}
        {showTable && selectedMetric === 'destport' && <TopDestPortsTable date={startDate} count={selectedCount} />}
        {showTable && selectedMetric === 'dest_ip' && <TopDestIPPerHourTable date={startDate} count={selectedCount} />}
      </div>
    </div>
  );
};

export default PacketsBarChart;



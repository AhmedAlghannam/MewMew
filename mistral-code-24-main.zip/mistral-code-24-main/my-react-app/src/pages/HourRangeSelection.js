import React from 'react';

const HourRangeSelection = ({ startHour, setStartHour, endHour, setEndHour }) => {
  const handleStartHourChange = (event) => {
    setStartHour(event.target.value);
  };

  const handleEndHourChange = (event) => {
    setEndHour(event.target.value);
  };

  const generateHourOptions = () => {
    return Array.from({ length: 24 }, (_, i) => (
      <option key={i} value={String(i).padStart(2, '0')}>
        {String(i).padStart(2, '0')}
      </option>
    ));
  };

  return (
    <div className="hour-range-selection">
      <label htmlFor="start-hour">Start Hour:</label>
      <select id="start-hour" value={startHour} onChange={handleStartHourChange}>
        {generateHourOptions()}
      </select>

      <label htmlFor="end-hour">End Hour:</label>
      <select id="end-hour" value={endHour} onChange={handleEndHourChange}>
        {generateHourOptions()}
      </select>
    </div>
  );
};

export default HourRangeSelection;

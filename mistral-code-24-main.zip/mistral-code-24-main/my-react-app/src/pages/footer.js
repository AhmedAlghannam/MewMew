import React from "react";
import "./footer.css";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import SocialFollow from "./socialFollow";

const Footer = () => {
  return (
    <footer className="footer">
      <Container>
        <Row className="align-items-start">
          <Col>
            <div className="address">
              <h3 className="footer-title">
                Security Analytics & Visualization Interface
              </h3>
              <p>
                300 Fuller Street
                <br />
                Durham, NC 27701
                <br />
                Internal: Duke Box 104100
              </p>
              <p>(919) 684-2200</p>
              <div className="social-media">
                <SocialFollow />
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;

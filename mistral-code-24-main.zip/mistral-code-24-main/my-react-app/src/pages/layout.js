import React from "react";
import backgroundImage from '../background.jpeg';
import mistralLogo from '../mistral.png';
import './layout.css'
import { Link } from "react-router-dom";

const Layout = ({ children, home}) => {
    return (
        <div>
            <div className="background" style={{backgroundImage: `url(${backgroundImage})`}}>
                <div className="logo">
                    <header className="master-header">
                        <img className="mistral" src={mistralLogo} alt="Mistral Logo" />
                        <div className="navigation-master">
                        {home === false && (
                            <Link to="/" className="navigation-master-link">Home</Link>
                        )}
                            <Link to="/search" className="navigation-master-link">Search</Link>
                        </div>
                    </header>
                    <div className="logo-line"></div>
                </div>
                <div className="main-page">
                    {children}
                </div>
            </div>
        </div>
    )
}

export default Layout;
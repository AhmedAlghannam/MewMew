import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title as ChartTitle,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import './toptalkers.css'; // Import the updated CSS file
import moment from 'moment-timezone';

// Register the required components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ChartTitle,
  Tooltip,
  Legend
);

const Timesearch = (props) => {
  const [data, setData] = useState([]);
  const [date, setDate] = useState(moment().tz('America/New_York').format('YYYY-MM-DD'));
  const [hour, setHour] = useState(moment().tz('America/New_York').hour());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: []
  });
  const [options, setOptions] = useState({});

  useEffect(() => {
    fetchData();
  }, [date, hour]);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get('http://localhost:4000/api/timesearch/', {
        params: {
          date,
          hour
        }
      });

      const sortedData = response.data.sort((a, b) => b.packetsSummary.bytes - a.packetsSummary.bytes).slice(0, 10);

      const formattedData = sortedData.map(item => ({
        ...item,
        packetsSummary: {
          ...item.packetsSummary,
          timestamp: formatTimestamp(item.packetsSummary.timestamp)
        }
      }));
      setData(formattedData);

      // Process data for chart
      const chartLabels = sortedData.map(item => item.srcIP.src_ip);
      const datasets = [{
        label: 'Bytes',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
        hoverBackgroundColor: 'rgba(75, 192, 192, 0.4)',
        hoverBorderColor: 'rgba(75, 192, 192, 1)',
        data: sortedData.map(item => item.packetsSummary.bytes)
      }];

      setChartData({
        labels: chartLabels,
        datasets: datasets
      });
    } catch (error) {
      console.error("Failed to fetch data:", error);
      setError("Failed to fetch data");
    } finally {
      setLoading(false);
    }
  };

  const formatTimestamp = (timestamp) => {
    const date = moment(timestamp).tz('America/New_York');
    return date.format('YYYY-MM-DD HH:mm:ss');
  };

  const maxValue = data.length > 0 ? Math.max(...data.map(item => item.packetsSummary.bytes)) : 0;
  const paddedMaxValue = Math.ceil(maxValue * 1.1);

  useEffect(() => {
    setOptions({
      scales: {
        y: {
          beginAtZero: true,
          max: paddedMaxValue
        }
      }
    });
  }, [data, paddedMaxValue]);

  return (
    <>
      <nav className="navbar">
        <div className="navbar-container">
          <div className="navbar-logo">My Navbar</div>
        </div>
      </nav>
      <div className="packets-body">
        <div className="packets-search-bar-container">
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="packets-search-bar"
          />
          <select
            value={hour}
            onChange={(e) => setHour(e.target.value)}
            className="packets-search-bar"
          >
            {[...Array(24).keys()].map(hour => (
              <option key={hour} value={hour}>{hour}</option>
            ))}
          </select>
        </div>
        <div>
          <h2 className="packets-summary-header">Bytes by Source IP</h2>
          <div className="bar-chart-container white-background">
            <Bar
              data={chartData}
              options={options}
            />
          </div>
        </div>
        <div>
          <h2 className="packets-summary-header">Packets Summary Table</h2>
          {error && <p className="error">{error}</p>}
          {loading ? (
            <p>Loading...</p>
          ) : (
            <table className="packets-summary-table">
              <thead>
                <tr>
                  <th className="packets-header-cell">Time</th>
                  <th className="packets-header-cell">Source IP</th>
                  <th className="packets-header-cell">Destination IP</th>
                  <th className="packets-header-cell">Destination Port</th>
                  <th className="packets-header-cell">Packets</th>
                  <th className="packets-header-cell">Reverse Packets</th>
                  <th className="packets-header-cell">Bytes</th>
                  <th className="packets-header-cell">Reverse Bytes</th>
                  <th className="packets-header-cell">Count</th>
                </tr>
              </thead>
              <tbody>
                {data.length > 0 ? (
                  data.map((item, index) => (
                    <tr key={index}>
                      <td className="packets-data-cell">{item.packetsSummary.timestamp}</td>
                      <td className="packets-data-cell">{item.srcIP ? item.srcIP.src_ip : 'N/A'}</td>
                      <td className="packets-data-cell">{item.destIP ? item.destIP.dest_ip : 'N/A'}</td>
                      <td className="packets-data-cell">{item.flowSummary.dest_port}</td>
                      <td className="packets-data-cell">{item.packetsSummary.packets}</td>
                      <td className="packets-data-cell">{item.packetsSummary.reverse_packets}</td>
                      <td className="packets-data-cell">{item.packetsSummary.bytes}</td>
                      <td className="packets-data-cell">{item.packetsSummary.reverse_bytes}</td>
                      <td className="packets-data-cell">{item.packetsSummary.count}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="9">No data available</td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}

export default Timesearch;

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import moment from 'moment-timezone';
import './toptalkers.css'; // Ensure you have appropriate styling

const TopDestPortsTable = ({ date, count }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchData();
  }, [date, count]);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get('http://localhost:4000/api/destporttable/', {
        params: { date, count }
      });

      const formattedData = response.data.map(item => ({
        hour: item.hour,
        dest_port: item.dest_port,
        packetsSummary: Array.isArray(item.packetsSummary) ? item.packetsSummary : [],
        flowSummary: item.flowSummary,
        srcIP: item.srcIP,
        destIP: item.destIP
      }));

      setData(formattedData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
      setError('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 className="packets-summary-header">Destination Port Table</h2>
      {error && <p className="error">{error}</p>}
      {loading ? (
        <p className="loading2">Loading...</p>
      ) : (
        data.length > 0 ? (
          <table className="packets-summary-table">
            <thead>
              <tr>
                <th className="packets-header-cell">Time</th>
                <th className="packets-header-cell">Destination Port</th>
                <th className="packets-header-cell">Source IP</th>
                <th className="packets-header-cell">Destination IP</th>
                <th className="packets-header-cell">Packets</th>
                <th className="packets-header-cell">Reverse Packets</th>
                <th className="packets-header-cell">Bytes</th>
                <th className="packets-header-cell">Reverse Bytes</th>
                <th className="packets-header-cell">Count</th>
              </tr>
            </thead>
            <tbody>
              {data.map((hourData, index) => (
                hourData.packetsSummary.map((packetsSummary, subIndex) => (
                  <tr key={`${index}-${subIndex}`}>
                    {subIndex === 0 && (
                      <>
                        <td rowSpan={hourData.packetsSummary.length} className="packets-data-cell">{hourData.hour}</td>
                        <td rowSpan={hourData.packetsSummary.length} className="packets-data-cell">{hourData.dest_port}</td>
                      </>
                    )}
                    <td className="packets-data-cell">{hourData.srcIP ? hourData.srcIP.src_ip : 'N/A'}</td>
                    <td className="packets-data-cell">{hourData.destIP ? hourData.destIP.dest_ip : 'N/A'}</td>
                    <td className="packets-data-cell">{packetsSummary.packets}</td>
                    <td className="packets-data-cell">{packetsSummary.reverse_packets}</td>
                    <td className="packets-data-cell">{packetsSummary.bytes}</td>
                    <td className="packets-data-cell">{packetsSummary.reverse_bytes}</td>
                    <td className="packets-data-cell">{packetsSummary.count}</td>
                  </tr>
                ))
              ))}
            </tbody>
          </table>
        ) : (
          <p>No data available</p>
        )
      )}
    </div>
  );
};

export default TopDestPortsTable;


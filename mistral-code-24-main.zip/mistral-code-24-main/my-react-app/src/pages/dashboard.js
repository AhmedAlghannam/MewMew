import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './dashboard.css';
import { Bar, Pie, Line } from 'react-chartjs-2';
import { Sankey } from 'recharts';
import DashboardNav from './dashboardNav.js';
import Footer from './footer.js';
import infoIcon from '../images/info-icon.png'; 
import infoIcon2 from '../images/infoicon2.png'; 
import infoIcon3 from '../images/infoicon3.png'; 
import infoIcon4 from '../images/infoicon4.png'; 
import infoIcon5 from '../images/infoicon5.png'; 

import InfoSourceIP from './infoSourceIP.js';
import InfoIPByte from './infoIPByte.js';
import InfoProtocol from './infoProtocol.js';
import InfoFlow from './infoFlow.js';
import InfoSankey from './infoSankey.js';


const Dashboard = () => {

    const [data, setData] = useState([]);
    const [topIpData, setTopIpData] = useState([]);
    const [topProtNumData, setTopProtNumData] = useState([]);
    const [topByteData, setTopByteData] = useState([]);
    const [topIp, setTopIp] = useState("");
    const [sankeyIpQuery, setSankeyIpQuery] = useState("");
    const [sankeyData, setSankeyData] = useState({ nodes: [], links: [] });
    const [flowData, setFlowData] = useState([]);
    const [currentPage, setCurrentPage] = useState('ip-byte-container');
    const [modalInfo, setModalInfo] = useState({ show: false, component: null });

    const handleInfoClick = (component) => {
        setModalInfo({ show: true, component });
    };
    

    const handleCloseModal = () => {
        setModalInfo({ show: false, component: null });
    };
    const [alertCounts, setAlertCounts] = useState({
        total_alerts: 0,
        high_alerts: 0,
        medium_alerts: 0,
        low_alerts: 0,
    });
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                // fetch data
                setLoading(true);
                const response = await axios.get('http://localhost:4000/api/toptalkerssearch/');
                const data = response.data;

                setData(data);

                // set top 10 ip data
                const ipData = data['source_ip_ten']
                const sortedIpData = ipData.sort((a, b) => b.src_ip_count - a.src_ip_count);
                const topIps = sortedIpData.slice(0, 10);

                setTopIpData(topIps.map(item => ({
                    src_ip: item['SourceIP.src_ip'],
                    count: item['src_ip_count'],
                })));

                // set top 10 protocol data
                const protData = data['prot_ten']
                const sortedProtData = protData.sort((a,b) => b.prot_count - a.prot_count);
                const topProt = sortedProtData.slice(0, 10);

                setTopProtNumData(topProt.map(item => ({
                    prot_num: item['FlowSummary.prot_num'],
                    count: item['prot_count']
                })));

                // set top 10 byte data
                const byteData = data['source_ip_ten']
                const sortedByteData = byteData.sort((a, b) => b['PacketsSummary.bytes'] - a['PacketsSummary.bytes']);
                const topByteData = sortedByteData.slice(0, 10);

                setTopByteData(topByteData.map(item => ({
                    src_ip: item['SourceIP.src_ip'],
                    bytes: item['PacketsSummary.bytes'],
                })));
                setTopIp(sortedByteData.slice(0, 1)[0]["SourceIP.src_ip"]);
                const topIpValue = sortedByteData.slice(0, 1)[0]["SourceIP.src_ip"]

                // set flow data
                const flowData = data['flow_count']
                setFlowData(flowData.map(item => ({
                    hour: item['hour'],
                    hourCount: item['hour_count'] 
                })))

                // set Sankey data
                const nodes = [];
                const links = [];

                const nodeMap = new Map();

                const getNodeIndex = (name) => {
                    if (!nodeMap.has(name)) {
                        nodeMap.set(name, nodes.length);
                        nodes.push({ name });
                    }
                    return nodeMap.get(name);
                };

                data['dest_src_bytes'].forEach(item => {
                    if(item.src_ip === topIpValue && links.length < 15) {
                        const sourceIndex = getNodeIndex(item.src_ip);
                        const destinationIndex = getNodeIndex(item.dst_ip);
                        links.push({
                            source: sourceIndex,
                            target: destinationIndex,
                            value: item.total_bytes,
                        });
                    }
                });

                setSankeyData({ nodes, links });

                const alertCountsResponse = await axios.get('http://localhost:4000/api/alert-counts/');
                setAlertCounts(alertCountsResponse.data);

            } catch (error) {
                console.error('Error fetching data:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    useEffect(() => {
        if(Object.keys(data).length > 0){
            const nodes = [];
            const links = [];

            const nodeMap = new Map();

            const getNodeIndex = (name) => {
                if (!nodeMap.has(name)) {
                    nodeMap.set(name, nodes.length);
                    nodes.push({ name });
                }
                return nodeMap.get(name);
            };

            data['dest_src_bytes'].forEach(item => {
                if(item.src_ip === topIp && links.length < 20) {
                    const sourceIndex = getNodeIndex(item.src_ip);
                    const destinationIndex = getNodeIndex(item.dst_ip);
                    links.push({
                        source: sourceIndex,
                        target: destinationIndex,
                        value: item.total_bytes,
                    });
                }
            });

            setSankeyData({ nodes, links });

        }
    }, [topIp])
    

    useEffect(() => {
    }, [topIp])

    const CustomNode = ({ x, y, width, height, index, payload, containerWidth, containerHeight, ...rest }) => {
            return (
                <g>
                    <rect
                        x={x}
                        y={y}
                        width={width}
                        height={height}
                        fill={payload.color || '#2C427B'}
                        stroke="none"
                        {...rest}
                    />
                    {index === 0 ? (
                        <text
                            className="node-number" 
                            x={x + width + 40}
                            y={y + height / 2}
                            dy=".35em"
                            textAnchor="middle"
                            fill="#000000"
                            fontSize={12}
                        >
                            {payload.name}
                        </text>
                    ) : (
                        <text
                            className="node-number2"
                            x={x + width - 60}
                            y={y + height / 2}
                            dy=".35em"
                            textAnchor="middle"
                            fill="#000000"
                            fontSize={12}
                        >
                            {payload.name}
                        </text>
                    )}
                </g>
            );
      };

    const changeSankeySource = (event) => {
        setSankeyIpQuery(event.target.value);
    }

    const submitSankeyQuery = () => {
        setTopIp(sankeyIpQuery);
    }

    const decreasePage = (setTarget, target) => {
        if(target > 0) {
            setTarget(target - 1);
        }
    }

    const increasePageIp = (setTarget, target) => {
        if(target < 1) {
            setTarget(target + 1);
        }
    }

    const topIpDataChart = {
        labels: topIpData.map(item => item.src_ip),
        datasets: [
            {
                label: 'Count',
                data: topIpData.map(item => item.count),
                backgroundColor: [
                    '#093f54',
                    '#005f73',
                    '#0a9396',
                    '#94d2bd',
                    '#e9d8a6',
                    '#ee9b00',
                    '#ca6702',
                    '#bb3e03',
                    '#ae2012',
                    '#7d191c'
                ],
                borderColor: [
                    '#093f54',
                    '#005f73',
                    '#0a9396',
                    '#94d2bd',
                    '#e9d8a6',
                    '#ee9b00',
                    '#ca6702',
                    '#bb3e03',
                    '#ae2012',
                    '#7d191c'
                ],
                borderWidth: 1,
            },
        ],
    };

    const pieOptions = {
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 30
                }
            },
        }
    };

    const topByteDataChart = {
        labels: topByteData.map(item => item.src_ip),
        datasets: [
            {
                label: 'Byte Counts',
                data: topByteData.map(item => item.bytes),
                backgroundColor: [
                    '#669bbc'
                ],
                borderColor: [
                    '#1a5478'
                ],
                borderWidth: 1,
            },
        ],
    };

    const topProtOptions = {
        scales: {
            x: {
                type: 'category',
                labels: topProtNumData.map(item => item.prot_num),
                ticks: {
                    font: {
                        size: 14,
                    },
                },
            },
            y: {
                beginAtZero: true,
                max: Math.max(...topProtNumData.map(item => item.count)) * 1.1,
                title: {
                    display: true,
                    text: 'Count',
                    font: {
                        size: 16,
                    },
                },
                ticks: {
                    font: {
                        size: 14,
                    },
                },
            },
        },
    };

    const topProtData = {
        labels: topProtNumData.map(item => item.prot_num),
        datasets: [
            {
                label: "# Of Connections",
                data: topProtNumData.map(item => item.count),
                backgroundColor: [
                    '#669bbc'
                ],
                borderColor: [
                    '#1a5478'
                ],
                borderWidth: 1,
            }
        ]
    }

    const flowDataChart = {
        labels: flowData.map(item => item.hour),
        datasets: [
          {
            label: 'Flow Data',
            data: flowData.map(item => item.hourCount),
            fill: true,
            backgroundColor: [
                '#669bbc'
            ],
            borderColor: [
                '#1a5478'
            ],
            borderWidth: 1,
          }
        ]
      };
    

    const flowDataOptions = {
        scales: {
            x: {
                type: "category",
                position: "bottom"
            },
            y: {
                type: "linear",
                position: "left"
            }
        }
    }



    return (
        <div>
            <DashboardNav />
            <div className="dashboard-container">
                <div className="master-chart-container">
                    {loading ? (
                        <p className="loading">Loading...</p>
                    ) : (
                        <>
                            <div className="alerts-dashboard chart-container">
                                <div className="alert-box all-alerts">
                                    <div className="alert-header">
                                        <span>All Alerts</span>
                                        <span className="alert-circle"></span>
                                    </div>
                                    <div className="alert-content">
                                        <span className="alert-count">{alertCounts.total_alerts}</span>
                                    </div>
                                    <div className="alert-info">
                                        # of all priority alerts today
                                    </div>
                                </div>
                                <div className="alert-box high-alert">
                                    <div className="alert-header">
                                        <span>High Alerts</span>
                                        <span className="alert-circle"></span>
                                    </div>
                                    <div className="alert-content">
                                        <span className="alert-count">{alertCounts.high_alerts}</span>
                                    </div>
                                    <div className="alert-info">
                                        # of high priority alerts today
                                    </div>
                                </div>
                                <div className="alert-box medium-alert">
                                    <div className="alert-header">
                                        <span>Medium Alerts</span>
                                        <span className="alert-circle"></span>
                                    </div>
                                    <div className="alert-content">
                                        <span className="alert-count">{alertCounts.medium_alerts}</span>
                                    </div>
                                    <div className="alert-info">
                                        # of medium priority alerts today
                                    </div>
                                </div>
                                <div className="alert-box low-alert">
                                    <div className="alert-header">
                                        <span>Low Alerts</span>
                                        <span className="alert-circle"></span>
                                    </div>
                                    <div className="alert-content">
                                        <span className="alert-count">{alertCounts.low_alerts}</span>
                                    </div>
                                    <div className="alert-info">
                                        # of low priority alerts today
                                    </div>
                                </div>
                            </div>
                            
                        {currentPage === 'ip-byte-container' && (
                            <div className="ip-byte-container chart-container">
                                <div className="ip-byte-chart-container">
                                    <div className="header-flex2">
                                        <h3>Source IP Addresses v. Bytes</h3>
                                        <img src={infoIcon} alt="Info" className="info-icon1" onClick={() => handleInfoClick(InfoIPByte)} />
                                    </div>
                                    <Bar data={topByteDataChart} />
                                </div>
                                <div className="pagination-dashboard">
                                    <button
                                        onClick={() => setCurrentPage('ip-byte-container')}
                                        className={currentPage === 'ip-byte-container' ? 'active' : ''}
                                    >
                                        IP-Byte
                                    </button>
                                    <button
                                        onClick={() => setCurrentPage('prot-container')}
                                        className={currentPage === 'prot-container' ? 'active' : ''}
                                    >
                                        Protocol
                                    </button>
                                    <button
                                        onClick={() => setCurrentPage('flow-container')}
                                        className={currentPage === 'flow-container' ? 'active' : ''}
                                    >
                                        Flow
                                    </button>
                                </div>
                            </div>
                        )}

                        {currentPage === 'prot-container' && (
                            <div className="prot-container chart-container">
                                <div className="prot-chart-container">
                                    <div className="header-flex3">
                                        <h3>Protocol Numbers</h3>
                                        <img src={infoIcon2} alt="Info" className="info-icon2" onClick={() => handleInfoClick(InfoProtocol)} />
                                    </div>
                                    <Bar data={topProtData} options={topProtOptions} />
                                </div>
                                <div className="pagination-dashboard">
                                    <button
                                        onClick={() => setCurrentPage('ip-byte-container')}
                                        className={currentPage === 'ip-byte-container' ? 'active' : ''}
                                    >
                                        IP-Byte
                                    </button>
                                    <button
                                        onClick={() => setCurrentPage('prot-container')}
                                        className={currentPage === 'prot-container' ? 'active' : ''}
                                    >
                                        Protocol
                                    </button>
                                    <button
                                        onClick={() => setCurrentPage('flow-container')}
                                        className={currentPage === 'flow-container' ? 'active' : ''}
                                    >
                                        Flow
                                    </button>
                                </div>
                            </div>
                        )}

                        {currentPage === 'flow-container' && (
                            <div className="flow-container chart-container">
                                <div className="flow-chart-container">
                                    <div className="header-flex4">
                                        <h3>Flow Over Time</h3>
                                        <img src={infoIcon3} alt="Info" className="info-icon3" onClick={() => handleInfoClick(InfoFlow)} />
                                    </div>
                                    <Line data={flowDataChart} options={flowDataOptions} />
                                </div>
                                <div className="pagination-dashboard">
                                    <button
                                        onClick={() => setCurrentPage('ip-byte-container')}
                                        className={currentPage === 'ip-byte-container' ? 'active' : ''}
                                    >
                                        IP-Byte
                                    </button>
                                    <button
                                        onClick={() => setCurrentPage('prot-container')}
                                        className={currentPage === 'prot-container' ? 'active' : ''}
                                    >
                                        Protocol
                                    </button>
                                    <button
                                        onClick={() => setCurrentPage('flow-container')}
                                        className={currentPage === 'flow-container' ? 'active' : ''}
                                    >
                                        Flow
                                    </button>
                                </div>
                            </div>
                        )}

                            <div className="ip-container" chart-container>
                                <div className="header-flex1">
                                    <h3>Source IP Addresses</h3>
                                    <img src={infoIcon4} alt="Info" className="info-icon4" onClick={() => handleInfoClick(InfoSourceIP)} />
                                </div>
                                <div className="ip-chart-container">
                                    <Pie data={topIpDataChart} options={pieOptions}/>
                                </div>
                            </div>
                            
                            <div className="sankey-container chart-container">
                                <div className="sankey-inner-container">
                                    <div className="individual-container-header">
                                        <div className="header-flex">
                                            <h3>Single Source IP Map</h3>
                                            <img src={infoIcon5} alt="Info" className="info-icon5" onClick={() => handleInfoClick(InfoSankey)} />
                                        </div>
                                        <div className="hi-sankey">    
                                            <p className="sankeyName"> Source IP:</p>
                                            <input onChange={changeSankeySource} className="inputBox"></input>
                                            <button onClick={submitSankeyQuery} className="container-toggle">
                                                <div className="renderButton">Render</div>
                                            </button>
                                        </div>
                                    </div>
                                    <div className="sankey-container-chart">
                                        {sankeyData.nodes.length > 0 && sankeyData.links.length > 0 && (
                                            <Sankey
                                            key={JSON.stringify(sankeyData)}
                                            width={1220}
                                            height={500}
                                            data={sankeyData}
                                            nodeWidth={15}
                                            nodePadding={10}
                                            layout="horizontal"
                                            node={CustomNode}
                                            />
                                        )}
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                    

                    {modalInfo.show && (
                        <modalInfo.component show={modalInfo.show} handleClose={handleCloseModal} />
                    )}

                </div>
            </div>
            <Footer />
            
            
        </div>
    );
}

export default Dashboard;


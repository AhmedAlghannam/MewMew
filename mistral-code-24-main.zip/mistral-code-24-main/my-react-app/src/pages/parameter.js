import React from 'react';
import './parameter.css'

const Parameter = ({ indexParameter, parameters, setParameters}) => {

    const fieldChange = (event) => {

        const parametersCopy = [...parameters];

        if(!parametersCopy[indexParameter]) {
            parametersCopy[indexParameter] = [];
        }
        parametersCopy[indexParameter][0]= event.target.value;
        setParameters(parametersCopy);
    };

    const valueChange = (event) => {
        const parametersCopy = [...parameters];

        if(!parametersCopy[indexParameter]) {
            parametersCopy[indexParameter] = [];
        }
        parametersCopy[indexParameter][1]= event.target.value;
        setParameters(parametersCopy);
    };

    const operationChange = (event) => {
        const parametersCopy = [...parameters];

        if(!parametersCopy[indexParameter]) {
            parametersCopy[indexParameter] = [];
        }
        parametersCopy[indexParameter][2]= event.target.value;
        setParameters(parametersCopy);
    }

    const joinChange = (event) => {
        const parametersCopy = [...parameters];

        if(!parametersCopy[indexParameter]) {
            parametersCopy[indexParameter] = [];
        }
        parametersCopy[indexParameter][3]= event.target.value;
        setParameters(parametersCopy);
    }
    

    return(
        <>
            {indexParameter >= 1 && (
                <div onChange={joinChange} className="operator-selector">
                    <select className="operator-select">
                        <option value=""></option>
                        <option value="AND">AND</option>
                        <option value="OR">OR</option>
                    </select>
                </div>
            )}
            <div className="single-parameter">
                <div className="group-search">
                    <h1>Field</h1>
                        <select onChange={fieldChange}>
                            <option value=""></option>
                            <option value="FlowSummary.dest_port">Destination Port</option>
                            <option value="SourceIP.src_ip">Source IP</option>
                            <option value="DestinationIP.dest_ip">Destination IP</option>
                            <option value="TimeStamps.date">Date</option>
                            <option value="TimeStamps.hour">Hour</option>
                        </select>
                </div>
                <div className="group-search">
                    <h1>Operation</h1>
                    <select onChange={operationChange}>
                        <option value=""></option>
                        <option value="lt">&lt;</option>
                        <option value="gt">&gt;</option>
                        <option value="le">&le;</option>
                        <option value="ge">&ge;</option>
                        <option value="eq">=</option>
                    </select>
                </div>
                <div className="group-search">
                    <h1>Value</h1>
                    <input
                        type="text"
                        className="master-search-bar"
                        onChange={valueChange}/>
                </div>
            </div>
        </>
    )
}

export default Parameter;
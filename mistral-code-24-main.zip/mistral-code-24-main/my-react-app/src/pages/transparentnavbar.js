import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './transparentnavbar.css';
import mistralLogo from '../mistraltransparent.png';

const TransparentNavBar = () => {
  const [isLifted, setIsLifted] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) { // Adjust the scroll value as needed
        setIsLifted(true);
      } else {
        setIsLifted(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <nav className={`container ${isLifted ? 'lifted' : ''}`}>
      <Link to="/">
        <img src={mistralLogo} alt='Mistral Logo' className='landing-logo' />
      </Link>
      <ul>
        {location.pathname !== '/teams' && (
          <li>
            <Link to="/teams" className="nav-link">Meet the Team</Link>
          </li>
        )}
      </ul>
    </nav>
  );
};

export default TransparentNavBar;

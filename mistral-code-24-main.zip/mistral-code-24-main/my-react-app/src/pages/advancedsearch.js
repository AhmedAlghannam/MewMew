import React, { useEffect, useState } from "react";
import axios from "axios";
import "./advancedsearch.css";
import SearchOption from "./searchoption";
import Pages from "./pages";
import ColumnChange from "./columnchange";
import DownloadPopup from "./downloadpopup";
import DashboardNav from "./dashboardNav.js";
import Footer from "./footer.js";

const columns = [
  { label: "Date", value: "TimeStamps.date" },
  { label: "Hour", value: "TimeStamps.hour" },
  { label: "Duration", value: "TimeStamps.duration" },
  { label: "Source IP", value: "SourceIP.src_ip" },
  { label: "Destination IP", value: "DestinationIP.dest_ip" },
  { label: "Destination Port", value: "FlowSummary.dest_port" },
  { label: "Protocol Number", value: "FlowSummary.prot_num" },
  { label: "Packets", value: "PacketsSummary.packets" },
  { label: "Reverse Packets", value: "PacketsSummary.reverse_packets" },
  { label: "Bytes", value: "PacketsSummary.bytes" },
  { label: "Reverse Bytes", value: "PacketsSummary.reverse_bytes" },
  { label: "Count", value: "TimeStamps.count" },
];

function DestPortSearch(props) {
  const [data, setData] = useState([]);
  const [values, setValues] = useState([[]]);
  const [fetchState, setFetchState] = useState(false);
  const [displayTable, setDisplayTable] = useState(false);
  const [rowCount, setRowCount] = useState(500);
  const [isLoading, setIsLoading] = useState(false);
  const [searchGroups, setSearchGroups] = useState([0]);
  const [selectedColumns, setSelectedColumns] = useState(
    columns.map((col) => col.value)
  );
  const [showRemoveButton, setShowRemoveButton] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const [sortedData, setSortedData] = useState([]);
  const [columnPopup, setColumnPopup] = useState(false);
  const [rowPopup, setRowPopup] = useState(false);
  const [downloadPopup, setDownloadPopup] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const columnsComma = selectedColumns.join(",");

        const paramObjects = {};
        values.forEach((group, index) => {
          const valueComma = values[index].join(",");
          paramObjects[searchGroups[index]] = valueComma;
        });

        const response = await axios.get(
          "http://localhost:4000/api/destportsearch/",
          {
            params: {
              ...paramObjects,
              columnsComma,
            },
          }
        );
        setData(response.data);
        setSelectedColumns(columns.map((col) => col.value));
        setSortedData(response.data);
        setDisplayTable(true);
      } catch (error) {
        console.error("Failed to fetch data:", error);
      }

      setIsLoading(false);
    };

    if (fetchState) {
      fetchData();
      setFetchState(false);
    }
  }, [searchGroups, values, fetchState, selectedColumns]);

  const handleSearch = () => {
    setDisplayTable(false);
    setIsLoading(true);
    setFetchState(true);
    // Reset sorting when performing a new search
    setSortConfig({ key: null, direction: "asc" });
  };

  const changeRowCount = (event) => {
    setRowCount(parseInt(event.target.value));
  };

  const addGroup = () => {
    setSearchGroups([...searchGroups, searchGroups.length]);
    setValues([...values, []]);
    setShowRemoveButton(true); // show remove button after adding group
  };

  const removeGroup = () => {
    if (searchGroups.length > 0) {
      const updatedGroups = [...searchGroups];
      updatedGroups.pop(); // remove the last search group
      setSearchGroups(updatedGroups);

      const updatedValues = [...values];
      updatedValues.pop(); // remove corresponding values
      setValues(updatedValues);

      if (updatedGroups.length === 0) {
        setShowRemoveButton(false); // hide remove button if no groups left
      }
    }
  };

  useEffect(() => {
    if (searchGroups.length === 1 && searchGroups[0] === 0) {
      setShowRemoveButton(false);
    }
  }, [searchGroups]);

  const pageChange = (event, pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    const numberOfPages = Math.ceil(data.length / rowCount);

    for (let index = 0; index < numberOfPages; index++) {
      pageNumbers.push(
        <span
          onClick={(event) => pageChange(event, index)}
          className={`page-number ${index === currentPage ? "active" : ""}`}
        >
          {index + 1}
        </span>
      );
    }

    if (pageNumbers.length < 4) return pageNumbers;
    else {
      return (
        <>
          {currentPage > 1 && (
            <>
              {pageNumbers[0]}
              <span className="page-number-dots">...</span>
            </>
          )}

          {pageNumbers.map(
            (page, index) =>
              (index - 1 === currentPage ||
                index === currentPage ||
                index + 1 === currentPage) &&
              page
          )}

          {currentPage < pageNumbers.length - 2 && (
            <>
              <span className="page-number-dots">...</span>
              {pageNumbers[pageNumbers.length - 1]}
            </>
          )}
        </>
      );
    }
  };

  useEffect(() => {
    const sortData = () => {
      const columnToSort = sortConfig.key;

      if (!columnToSort) {
        setSortedData(data);
        return;
      }

      const sorted = [...data].sort((a, b) => {
        const aValue = a[columnToSort];
        const bValue = b[columnToSort];

        if (aValue < bValue) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });

      setSortedData(sorted);
    };

    sortData();
  }, [data, sortConfig]);

  const toggleColumnPopup = () => {
    setColumnPopup(!columnPopup);
  };

  return (
    <>
      <DashboardNav />
      {downloadPopup && (
        <DownloadPopup setDownloadPopup={setDownloadPopup} data={data} />
      )}
      <head>
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1.0"
        ></meta>
      </head>
      <div className="advanced-body">
        <div className="search-parameters-master-container">
          <div className="box1-and-searchButton-container">
            {searchGroups.map((option, index) => (
              <SearchOption
                key={index}
                index={index}
                values={values}
                setValues={setValues}
                searchGroups={searchGroups}
                setSearchGroups={setSearchGroups}
              />
            ))}
            <button className="advanced-search-button" onClick={handleSearch}>
              Search
            </button>
          </div>

          <div className="additional-options">
            <h1>Advanced Search</h1>
            <button className="add-group-button" onClick={addGroup}>
              Add Search Group
            </button>
            {showRemoveButton && (
              <button className="remove-group-button" onClick={removeGroup}>
                Remove Search Group
              </button>
            )}
            <hr></hr>
            <button className="modify-columns" onClick={toggleColumnPopup}>
              <span> Columns </span>
              {columnPopup ? <span> ⌃ </span> : <span> ⌄ </span>}
            </button>
            {columnPopup && (
              <ColumnChange
                selectedColumns={selectedColumns}
                setSelectedColumns={setSelectedColumns}
              />
            )}
            <hr></hr>
            <button
              className="modify-columns"
              onClick={() => setRowPopup(!rowPopup)}
            >
              <span> Rows Per Page </span>

              {rowPopup ? <span> ⌃ </span> : <span> ⌄ </span>}
            </button>
            {rowPopup && (
              <select
                value={rowCount}
                onChange={changeRowCount}
                className="rowCount"
              >
                <option value="500">500</option>
                <option value="1000">1000</option>
                <option value="5000">5000</option>
                <option value="10000">10000</option>
                <option value="50000">50000</option>
                <option value="100000">100000</option>
              </select>
            )}
          </div>
        </div>

        <div>
          {isLoading ? (
            <div>
              <p className="loading">Loading...</p>
            </div>
          ) : (
            displayTable && (
              <React.Fragment>
                <div className="page-table-container">
                  <div className="page-table">
                    <div className="table-header">
                      <button
                        onClick={() => {
                          setDownloadPopup(true);
                        }}
                        className="download-button"
                      >
                        Export Data
                      </button>
                      {data.length !== 0 && (
                        <div className="pagination">
                          <span
                            onClick={() => {
                              if (currentPage > 0)
                                setCurrentPage(currentPage - 1);
                            }}
                            className="arrowheads"
                          >
                            ◀
                          </span>

                          {renderPageNumbers()}

                          <span
                            onClick={() => {
                              if (
                                currentPage <
                                Math.ceil(data.length / rowCount) - 1
                              )
                                setCurrentPage(currentPage + 1);
                            }}
                            className="arrowheads"
                          >
                            ▶
                          </span>
                        </div>
                      )}
                    </div>
                    <table className="result_table">
                      <Pages
                        data={sortedData}
                        numberofRows={rowCount}
                        currentPage={currentPage}
                        sortConfig={sortConfig}
                        setSortConfig={setSortConfig}
                      />
                    </table>
                  </div>
                </div>
              </React.Fragment>
            )
          )}
        </div>
      </div>
      <Footer />
    </>
  );
}

export default DestPortSearch;

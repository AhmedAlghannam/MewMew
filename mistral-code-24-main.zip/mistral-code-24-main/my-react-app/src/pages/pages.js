import React, {useEffect, useState } from "react";

const Pages = ({ data, numberofRows, currentPage, sortConfig, setSortConfig}) => {

    const columns = [
        { label: "Date", value: "TimeStamps.date" },
        { label: "Hour", value: "TimeStamps.hour" },
        { label: "Duration", value: "TimeStamps.duration" },
        { label: "Source IP", value: "SourceIP.src_ip" },
        { label: "Destination IP", value: "DestinationIP.dest_ip" },
        { label: "Destination Port", value: "FlowSummary.dest_port" },
        { label: "Protocol Number", value: "FlowSummary.prot_num" },
        { label: "Packets", value: "PacketsSummary.packets" },
        { label: "Reverse Packets", value: "PacketsSummary.reverse_packets" },
        { label: "Bytes", value: "PacketsSummary.bytes" },
        { label: "Reverse Bytes", value: "PacketsSummary.reverse_bytes" },
        { label: "Count", value: "TimeStamps.count" }
    ];

    const [dataDisplay, setDataDisplay] = useState([]);

    const handleSort = (value) => {
        let direction = 'asc';
        if (sortConfig.key === value && sortConfig.direction === 'asc') {
            direction = 'desc';
        } else if (sortConfig.key === value && sortConfig.direction === 'desc') {
            setSortConfig({ key: null, direction: 'asc' });
            return;
        }
        setSortConfig({ key: value, direction });
    };

    const getLabelByValue = (value) => {
        const column = columns.find(col => col.value === value);
        return column ? column.label : null;
    }

    useEffect(() => {
        const pagedData = data.slice(currentPage * numberofRows, (currentPage + 1) * numberofRows);
        setDataDisplay(pagedData);

    }, [currentPage, data, numberofRows, sortConfig])

    if(data === null || data === undefined || data.length === 0){

        console.log("null")
        return (
            <>
                <thead>
                    <tr>
                        {columns.map(header => (
                            <th key={header.label}>
                                {header.label}
                            </th>
                        ))} 
                    </tr>
                </thead>
            </>
        );
    }

    else {

        console.log("not null");
        console.log(data);
        const keys = Object.keys(data[0]);

        return (
            <>
                <thead>
                    <tr>
                        {keys.map(header => (
                            <th key={header} onClick={() => handleSort(header)}>
                                {getLabelByValue(header)}
                                {sortConfig.key === header && (
                                    <span className="arrow">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                                )}
                            </th>
                        ))} 
                    </tr>
                </thead>
                <tbody>
                    {dataDisplay.map((row, rowIndex) => (
                        <tr key={rowIndex}>
                            {keys.map((element, colIndex) => (
                                <td key={colIndex}>{row[element]}</td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </>
        );
    }
}

export default Pages;
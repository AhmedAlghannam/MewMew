import React, {useState, useEffect} from 'react';
import './headersidenav.css'

const HeaderSideNav = ( {children }) => {

	const [open, setOpen] = useState(false);
	const [isFixed, setIsFixed] = useState(false);

	useEffect(() => {
		const handleScroll = () => {
			const scrollY = window.scrollY;
			const headerHeight = document.querySelector('.navbar').offsetHeight;

			if (scrollY > headerHeight) {
				setIsFixed(true);
			} else {
				setIsFixed(false);
			}
		};
	
		window.addEventListener('scroll', handleScroll);
		return () => window.removeEventListener('scroll', handleScroll);
	}, []);

	return (
		<div className="dashboard-master-container">
			<div className="dashboard-lower-container">
				<div className={`sidebar-placeholder ${open ? 'open' : ''}`}>
					<div className={`sidebar ${open ? 'open': ''} ${isFixed ? 'fixed' : ''}`}>
							open = {open}
							setOpen = {setOpen}
					</div>
				</div>
				<div className="dashboard-right-side">
					{children}
				</div>
			</div>
		</div>
	);
}

export default HeaderSideNav;
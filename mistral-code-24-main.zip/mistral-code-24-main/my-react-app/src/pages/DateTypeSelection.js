import React from 'react';

import './DateTypeSelection.css';

const DateTypeSelection = ({ date, setDate, selectedMetric, setSelectedMetric, selectedCount, setSelectedCount}) => {

  const handleOptionChange = (option) => {
    setSelectedMetric(option);
  };

  const handleDateChange = (event) => {
    setDate(event.target.value);
  };

  const handleCountChange =  (event) => {
    setSelectedCount(event.target.value);
  }

  return (
    <div className="date-type-selection-box">
      <div className="date-selection">
        <label htmlFor="date">Select Date:</label>
        <input
          type="date"
          id="date"
          value={date}
          onChange={handleDateChange}
        />
      </div>
      <div className="type-selection">
        <p className="visualization-input-labels">Select Graph Category:</p> 
        <select value={selectedMetric} onChange={(e) => handleOptionChange(e.target.value)}>
          <option value="src_ip">Source IP</option>
          <option value="dest_ip">Destination IP</option>
          <option value="packets">Packets</option>
          <option value="dest_port">Destination Port</option>
          <option value="octets">Bytes</option>
        </select>
      </div>
      
      {(selectedMetric === 'src_ip' || selectedMetric === 'dest_ip' || selectedMetric === 'destport') && (
        <div className="count-selection">
          <p className="visualization-input-labels">Select Count:</p>
          <select value={selectedCount} onChange={(e) => handleCountChange(e.target.value)}>
            <option value="5">5</option>
            <option value="10">10</option>
            <option value="15">15</option>
          </select>
        </div>
      )}
    </div>
  );
};

export default DateTypeSelection;



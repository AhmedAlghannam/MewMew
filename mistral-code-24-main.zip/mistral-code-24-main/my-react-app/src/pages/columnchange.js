import React from 'react';
import './columnchange.css';

const ColumnChange = ({ selectedColumns, setSelectedColumns }) => {

    const columns = [
        { label: "Date", value: "TimeStamps.date" },
        { label: "Hour", value: "TimeStamps.hour" },
        { label: "Duration", value: "TimeStamps.duration" },
        { label: "Source IP", value: "SourceIP.src_ip" },
        { label: "Destination IP", value: "DestinationIP.dest_ip" },
        { label: "Destination Port", value: "FlowSummary.dest_port" },
        { label: "Protocol Number", value: "FlowSummary.prot_num" },
        { label: "Packets", value: "PacketsSummary.packets" },
        { label: "Reverse Packets", value: "PacketsSummary.reverse_packets" },
        { label: "Bytes", value: "PacketsSummary.bytes" },
        { label: "Reverse Bytes", value: "PacketsSummary.reverse_bytes" },
        { label: "Count", value: "TimeStamps.count" }
    ];

    const handleColumnChange = (event) => {
        const value = event.target.value;
        setSelectedColumns(prevSelectedColumns =>
            prevSelectedColumns.includes(value)
                ? prevSelectedColumns.filter(col => col !== value)
                : [...prevSelectedColumns, value]
        );
    };

    const toggleAllColumns = () => {
        if (selectedColumns.length === 0) {
            setSelectedColumns(columns.map(col => col.value));
        } else {
            setSelectedColumns([]);
        }
    };

    return (
        <div className="column-selection-master">
            <div className="column-selection">
                {columns.map(col => (
                    <div key={col.value}>
                        <input
                            type="checkbox"
                            id={col.value}
                            value={col.value}
                            checked={selectedColumns.includes(col.value)}
                            onChange={handleColumnChange}
                        />
                        <label htmlFor={col.value}>{col.label}</label>
                    </div>
                ))}
            </div>
            <button onClick={toggleAllColumns} className="all-column-button">Select All Columns</button>
        </div>
    )
}

export default ColumnChange;
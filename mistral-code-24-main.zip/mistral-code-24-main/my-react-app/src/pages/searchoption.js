import React, { useEffect, useState } from 'react';
import './searchoption.css';
import Parameter from './parameter';

const SearchOption = ({ index, values, setValues, searchGroups, setSearchGroups }) => {
    
    const [parameters, setParameters] = useState([values[index] || []]);
    const [collapsed, setCollapsed] = useState(false);

    // whenever parameter changes, we update the values
    useEffect(() => {

        // all values
        const valuesCopy = [...values];

        // extracts all parameters that we have for the current group
        valuesCopy[index] = parameters

        // sets the group
        setValues(valuesCopy)

    // eslint-disable-next-line
    }, [parameters, index, setValues])


    const addParameter = () => {
        setParameters([...parameters, []])
    }

    const removeParameter = (indexParameter) => {
        const updatedParameters = parameters.filter((_, idx) => idx !== indexParameter);
        setParameters(updatedParameters);
    };

    const groupJoinChange = (event) => {
        const searchGroupCopy = [...searchGroups];

        searchGroupCopy[index] = index + event.target.value;

        setSearchGroups(searchGroupCopy)
    }

    return (
        <div className="search-option-container">
            <div className="parameter-search">
                <div className="group-header">
                    <h2 className="group-title">Group {index + 1}</h2>
                    <div className="group-right-menu">
                        {index >= 1 && (
                            <div onChange={groupJoinChange}className="operator-selector">
                                <select className="operator-select">
                                    <option value=""></option>
                                    <option value="AND">AND</option>
                                    <option value="OR">OR</option>
                                </select>
                            </div>
                        )}
                    </div>
                </div>
                {!collapsed &&
                    <>
                        <div className="parameter-list">
                            {parameters.map((parameter, indexParameter) => (
                                <Parameter
                                    key={indexParameter}
                                    indexParameter={indexParameter}
                                    parameters={parameters}
                                    setParameters={setParameters}
                                />
                            ))}
                        </div>
                        <div style={{ display: 'flex' }}>
                            <button className="add-parameter-button" onClick={addParameter}>
                                Add Search Parameter
                            </button>
                            {parameters.length > 1 && (
                                <button className="remove-parameter-button" onClick={() => removeParameter(parameters.length - 1)}>
                                    Remove Search Parameter
                                </button>
                            )}
                        </div>
                    </>
                }
            </div>
        </div>
    );
};

export default SearchOption;
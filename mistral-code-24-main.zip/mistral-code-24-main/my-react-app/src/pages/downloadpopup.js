import React, { useState } from "react";
import './downloadpopup.css';

const DownloadPopup = ({ setDownloadPopup, data }) => {

    const [fileName, setFileName] = useState("");
    const [fileType, setFileType] = useState("");

    const changeFileName = (event) => {
        setFileName(event.target.value);
    }

    const changeFileType = (event) => {
        setFileType(event.target.value);
    }

    const handleDownload = () => {
        let blob;
        if(fileType === "json"){
            blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        } else if(fileType === "csv") {
            blob = new Blob([convertToCSV(data)], { type: 'text/csv' });
        }

        const urlBlob = window.URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = urlBlob;
        link.download = `${fileName}.${fileType}`;
        document.body.appendChild(link);
        link.click();

        document.body.removeChild(link);
        window.URL.revokeObjectURL(urlBlob);
    }

    const convertToCSV = (jsonArray) => {
        if (!jsonArray.length) {
            return '';
        }
    
        const keys = Object.keys(jsonArray[0]);
        const csvRows = [];
    
        // Add the header row
        csvRows.push(keys.join(','));
    
        // Add the data rows
        jsonArray.forEach((obj) => {
            const values = keys.map(key => {
                let value = obj[key];
                if (typeof value === 'string') {
                    // Escape quotes and commas
                    value = value.replace(/"/g, '""');
                    value = `"${value}"`;
                }
                return value;
            });
            csvRows.push(values.join(','));
        });
    
        return csvRows.join('\n');
    };

    

    return (
        <div className="popup-master">
            <div className="popup-content">
                <button onClick={() => {setDownloadPopup(false)}} className="download-close">x</button>
                <div className="popup-content2">
                    <h1 className="download-header">Download Data</h1>
                    <div className="popup-parameters">
                        <div className="file-parameters">
                            <p>File Name:</p>
                            <input onChange={changeFileName}></input>
                        </div>
                        <div className="file-parameters">
                            <p>File Type:</p>
                            <select onChange={changeFileType}>
                                <option value="csv"></option>
                                <option value="csv">.csv</option>
                                <option value="json">.json</option>
                            </select>
                        </div>
                    </div>
                    <button className="download-popup-button" onClick={handleDownload}>Download</button>
                </div>
            </div>
        </div>
    )
}

export default DownloadPopup;
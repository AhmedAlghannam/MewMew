import React from 'react';
import { Helmet } from 'react-helmet';
import './login.css';
import Layout from './layout';
import mistralLogo from '../mistral.png';

function Login(props) {
    return (
        <Layout home={props.home}>
            <Helmet>
                <meta name="viewport" content="width=device-width, initial-scale=1.0, height=device-height" />
            </Helmet>
            <div className="login-page">
                <div className="login-container">
                    <img src={mistralLogo} alt="Mistral Logo" className="mistral-logo" />
                    <form className="login-form">
                        <input type="text" placeholder="Username" className="login-input" />
                        <input type="password" placeholder="Password" className="login-input" />
                        <button type="submit" className="login-button">Sign In</button>
                    </form>
                    <p className="terms-text">
                        By clicking continue, you agree to our <a href="/terms">Terms of Service</a> and <a href="/privacy">Privacy Policy</a>
                    </p>
                </div>
            </div>
        </Layout>
    );
}

export default Login;
import React from 'react';
import './infoProtocol.css'; 

const InfoProtocol = ({ show, handleClose }) => {
    return (
        <div className={`protocol-modal ${show ? 'protocol-show' : ''}`} onClick={handleClose}>
            <div className="protocol-modal-content" onClick={e => e.stopPropagation()}>
                <span className="protocol-modal-close" onClick={handleClose}>&times;</span>
                <h2>Protocol Numbers</h2>
                <p>The bar chart displays the # of flows per hour. </p>
            </div>
        </div>
    );
};

export default InfoProtocol;

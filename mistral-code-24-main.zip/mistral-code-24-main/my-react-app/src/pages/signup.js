import React from 'react';
import { Helmet } from 'react-helmet';
import './signup.css';
import Layout from './layout';
import mistralLogo from '../mistral.png'; 

function Signup(props) {
    return (
        <Layout home={props.home}>
            <Helmet>
                <meta name="viewport" content="width=device-width, initial-scale=1.0, height=device-height" />
            </Helmet>
            <div className="signup-page">
                <div className="signup-container">
                    <img src={mistralLogo} alt="Mistral Logo" className="mistral-logo" />
                    <form className="signup-form">
                        <div className="input-row">
                            <input type="text" placeholder="Last Name" className="signup-input" />
                            <input type="text" placeholder="First Name" className="signup-input" />
                        </div>
                        <div className="input-row">
                            <input type="text" placeholder="Institution" className="signup-input" />
                            <input type="email" placeholder="Email" className="signup-input" />
                        </div>
                        <div className="input-row">
                            <input type="text" placeholder="Username" className="signup-input" />
                            <input type="password" placeholder="Password" className="signup-input" />
                        </div>
                        <button type="submit" className="signup-button">Create Account</button>
                    </form>
                    <p className="terms-text">
                        By clicking continue, you agree to our <a href="/terms">Terms of Service</a> and <a href="/privacy">Privacy Policy</a>
                    </p>
                </div>
            </div>
        </Layout>
    );
}

export default Signup;
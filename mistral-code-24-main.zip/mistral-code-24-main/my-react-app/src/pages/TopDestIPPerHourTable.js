import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import moment from 'moment-timezone';
import './toptalkers.css'; // Ensure you have appropriate styling

const TopDestIPPerHourTable = ({ date, count }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log(`Fetching data for date: ${date} with count: ${count}`);
      const response = await axios.get('http://localhost:4000/api/top-dest-ip-per-hour/', {
        params: { date, count }
      });
      console.log('API Response:', response.data);

      const formattedData = response.data.map(item => ({
        hour: item.hour,
        packetsSummary: {
          ...item.packetsSummary,
          timestamp: formatTimestamp(item.packetsSummary.timestamp)
        },
        destIP: item.destIP
      }));

      setData(formattedData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
      setError('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  }, [date, count]);

  useEffect(() => {
    if (date) {
      fetchData();
    }
  }, [fetchData, date, count]);

  const formatTimestamp = (timestamp) => {
    const date = moment(timestamp).tz('America/New_York');
    return date.format('YYYY-MM-DD HH:mm:ss');
  };

  return (
    <div>
      <h2 className="packets-summary-header">Destination IP Table</h2>
      {error && <p className="error">{error}</p>}
      {loading ? (
        <p className="loading2">Loading...</p>
      ) : (
        data.length > 0 ? (
          <table className="packets-summary-table">
            <thead>
              <tr>
                <th className="packets-header-cell">Time</th>
                <th className="packets-header-cell">Destination IP</th>
                <th className="packets-header-cell">Packets</th>
                <th className="packets-header-cell">Reverse Packets</th>
                <th className="packets-header-cell">Bytes</th>
                <th className="packets-header-cell">Reverse Bytes</th>
                <th className="packets-header-cell">Count</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item, index) => (
                <tr key={index}>
                  <td className="packets-data-cell">{item.packetsSummary.timestamp}</td>
                  <td className="packets-data-cell">{item.destIP ? item.destIP.dest_ip : 'N/A'}</td>
                  <td className="packets-data-cell">{item.packetsSummary.packets}</td>
                  <td className="packets-data-cell">{item.packetsSummary.reverse_packets}</td>
                  <td className="packets-data-cell">{item.packetsSummary.bytes}</td>
                  <td className="packets-data-cell">{item.packetsSummary.reverse_bytes}</td>
                  <td className="packets-data-cell">{item.packetsSummary.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No data available</p>
        )
      )}
    </div>
  );
};

export default TopDestIPPerHourTable;


import React from 'react';
import './infoSourceIP.css'; 

const InfoSourceIP = ({ show, handleClose }) => {
    return (
        <div className={`sourceip-modal ${show ? 'sourceip-show' : ''}`} onClick={handleClose}>
            <div className="sourceip-modal-content" onClick={e => e.stopPropagation()}>
                <span className="sourceip-modal-close" onClick={handleClose}>&times;</span>
                <h2>Source IP Addresses</h2>
                <p>The pie chart displays the daily top 10 source IP addresses. </p>
            </div>
        </div>
    );
};

export default InfoSourceIP;

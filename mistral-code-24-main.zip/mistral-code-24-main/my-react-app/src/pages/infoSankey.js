import React from 'react';
import './infoSankey.css'; 

const InfoSankey = ({ show, handleClose }) => {
    return (
        <div className={`sankey-modal ${show ? 'sankey-show' : ''}`} onClick={handleClose}>
            <div className="sankey-modal-content" onClick={e => e.stopPropagation()}>
                <span className="sankey-modal-close" onClick={handleClose}>&times;</span>
                <h2>Single Source IP Map</h2>
                <p>This sankey diagram shows the top destination IP connections from the source IP the user inputs. </p>
            </div>
        </div>
    );
};

export default InfoSankey;

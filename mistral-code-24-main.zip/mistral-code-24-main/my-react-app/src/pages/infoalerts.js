import React from 'react';
import './infoalerts.css'; 

const InfoModal = ({ show, handleClose }) => {
    return (
        <div className={`alerts-modal ${show ? 'alerts-show' : ''}`} onClick={handleClose}>
            <div className="alerts-modal-content" onClick={e => e.stopPropagation()}>
                <span className="alerts-modal-close" onClick={handleClose}>&times;</span>
                <h2>Information</h2>
                <p>When a date is not selected, the tables display alert data from the past 3 days.</p>
                <p>The model probability prediction is based on the number of unique destination ports a source IP connects with in a day, the number of packets and bytes sent from client to server, the number of bytes sent from server to client, PCR, and POR.</p>
                <p>PCR is the produce consumption ratio. POR tells us if transmissions are heavy or light in data.</p>
            </div>
        </div>
    );
};

export default InfoModal;

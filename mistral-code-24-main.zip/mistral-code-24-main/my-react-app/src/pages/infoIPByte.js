import React from 'react';
import './infoIPByte.css'; 

const InfoIPByte = ({ show, handleClose }) => {
    return (
        <div className={`IPBytemodal ${show ? 'IPByte-show' : ''}`} onClick={handleClose}>
            <div className="IPByte-modal-content" onClick={e => e.stopPropagation()}>
                <span className="IPByte-modal-close" onClick={handleClose}>&times;</span>
                <h2>Source IP Addresses vs. Bytes</h2>
                <p>The bar chart displays the daily top 10 source IP addresses and their byte counts. </p>
            </div>
        </div>
    );
};

export default InfoIPByte;

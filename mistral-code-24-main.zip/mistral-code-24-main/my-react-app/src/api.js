import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8000/wel',
});

export const fetchData = async () => {
  const response = await api.get('/endpoint/');
  return response.data;
};
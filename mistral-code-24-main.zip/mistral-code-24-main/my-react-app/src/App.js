import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/login';
import Signup from './pages/signup';
import Timesearch from './pages/toptalkers';
import Overview from './pages/overview';
import DestPortSearch from './pages/advancedsearch';
import Alerts from './pages/alerts';
import Landing from './pages/landing';
import StackedBarChart from './pages/StackedBarChart';
import Dashboard from './pages/dashboard';
import Teams from './pages/teams';
import DateTypeSelection  from './pages/DateTypeSelection';


function App() {
  return (
    <React.StrictMode>
      <Router>
        <div className="App">
          <Routes>
            <Route path="/" element={<Landing home={false}/>} />
            <Route path="/app/dashboard" element={<Dashboard/>} />
            <Route path="/login" element={<Login home={false}/>} />
            <Route path="/signup" element={<Signup home={false}/>} />
            <Route path="/app/toptalkers" element={<Timesearch home={false}/>} />
            <Route path="/app/visualizations" element={<Overview home={false}/>} />
            <Route path="/app/advancedsearch" element={<DestPortSearch home={true}/>} />
            <Route path="/app/alerts" element={<Alerts home={false}/>}/>
            <Route path="/landing" element={<Landing home={false}/>}/>
            <Route path="/stackedbarchart" element={<StackedBarChart home={false}/>}/>
			      <Route path="/teams" element={<Teams home={false}/>}/>
            <Route path="/DateTypeSelection" element={<DateTypeSelection home={false}/>}/>
          </Routes>
        </div>
      </Router>
    </React.StrictMode>
  );
}

export default App;

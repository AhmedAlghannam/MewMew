const http = require('http');
const express = require('express');
const app = express();

app.get('/proxy-endpoint', (req, res) => {
  const options = {
    hostname: 'frontend',
    port: 3000,
    path: '/api',
    method: 'GET',
  };

  const proxyReq = http.request(options, (proxyRes) => {
    let data = '';

    // A chunk of data has been received.
    proxyRes.on('data', (chunk) => {
      data += chunk;
    });

    // The whole response has been received.
    proxyRes.on('end', () => {
      res.send(data);
    });
  });

  proxyReq.on('error', (error) => {
    console.error(`Problem with request: ${error.message}`);
    res.status(500).send('Error connecting to the frontend service');
  });

  proxyReq.end();
});

app.listen(4000, () => {
  console.log('Proxy server listening on port 4000');
});
